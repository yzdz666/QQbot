<?php
if (!isset($_COOKIE['admin_token'])) {
    header("Location: index.php");
    exit();
}

// 读取 AI 配置（独立文件）
$aiConfigFile = dirname(__DIR__) . '/ai_config.json';
if (file_exists($aiConfigFile)) {
    $ai = json_decode(file_get_contents($aiConfigFile), true);
    if (!isset($ai['base_url'])) $ai['base_url'] = 'https://api.openai.com/v1';
    if (!isset($ai['api_key'])) $ai['api_key'] = '';
    if (!isset($ai['model'])) $ai['model'] = 'gpt-4o-mini';
} else {
    $ai = ['base_url' => 'https://api.openai.com/v1', 'api_key' => '', 'model' => 'gpt-4o-mini'];
}

// 判断是否已设置 API Key
$hasApiKey = !empty($ai['api_key']);
// 显示值：如果有密钥显示占位符，否则空
$displayKey = $hasApiKey ? '••••••••' : '';
// 真实密钥（用于JS初始化）
$realKey = $hasApiKey ? $ai['api_key'] : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>AI 写插件 · 月下独酌管机</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        :focus { outline:none; }
        :root {
            --bg: #f8fafc; --card: #ffffff; --border: #e9edf2;
            --text-main: #1a2c3e; --text-sub: #5e6f8d; --text-muted: #8b9ab0;
            --primary: #2c6b9e; --primary-hover: #235b87;
            --danger: #c23d2e; --danger-hover: #a83426;
            --success: #2c6e2c; --info: #2c6e9e;
            --sidebar-width: 240px; --header-height: 52px;
        }
        body { background: var(--bg); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: var(--text-main); line-height: 1.5; overflow-x: hidden; width: 100%; }
        .desktop-layout { display: flex; min-height: 100vh; }
        .sidebar { width: var(--sidebar-width); background: var(--card); border-right: 1px solid var(--border); position: fixed; top: 0; bottom: 0; left: 0; display: flex; flex-direction: column; z-index: 100; }
        .sidebar-header { padding: 20px 24px; border-bottom: 1px solid var(--border); }
        .sidebar-header h1 { font-size: 18px; font-weight: 600; }
        .sidebar-header p { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        .sidebar-nav { flex: 1; padding: 16px 0; overflow-y: auto; }
        .nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 24px; color: var(--text-sub); text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.15s; cursor: pointer; }
        .nav-item:hover { background: #f1f5f9; color: var(--primary); }
        .nav-item.active { background: #f1f5f9; color: var(--primary); border-left: 3px solid var(--primary); padding-left: 21px; }
        .nav-item i { width: 20px; font-size: 15px; }
        .sidebar-footer { padding: 16px 24px; border-top: 1px solid var(--border); font-size: 11px; color: var(--text-muted); }
        .main-content { flex: 1; margin-left: var(--sidebar-width); min-height: 100vh; min-width: 0; overflow-x: hidden; }
        .top-bar { background: var(--card); border-bottom: 1px solid var(--border); padding: 0 32px; height: var(--header-height); display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 10; }
        .page-title { font-size: 15px; font-weight: 500; }
        .container { padding: 28px 32px; max-width: 1200px; }
        .section-card { background: var(--card); border: 1px solid var(--border); border-radius: 10px; overflow: hidden; margin-bottom: 20px; }
        .section-header { padding: 16px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
        .section-title { font-size: 16px; font-weight: 600; }
        .section-sub { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
        .section-body { padding: 20px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 13px; font-weight: 500; color: var(--text-sub); margin-bottom: 6px; }
        .form-control, .form-select { width: 100%; padding: 8px 12px; font-size: 14px; border: 1px solid var(--border); border-radius: 6px; font-family: inherit; background: var(--card); max-width: 100%; }
        .form-control:focus { border-color: var(--primary); }
        textarea.form-control { min-height: 80px; resize: vertical; font-family: 'SF Mono', monospace; font-size: 13px; }
        .code-editor { font-family: 'SF Mono', monospace; font-size: 13px; line-height: 1.6; min-height: 300px; resize: vertical; }
        .btn { padding: 6px 14px; font-size: 13px; font-weight: 500; border-radius: 6px; cursor: pointer; border: none; display: inline-flex; align-items: center; gap: 6px; transition: all 0.15s; }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-secondary { background: #f1f5f9; color: var(--text-sub); border: 1px solid var(--border); }
        .btn-secondary:hover { background: #e9edf2; }
        .btn-success { background: var(--success); color: white; }
        .btn-success:hover { background: #1f5a1f; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: var(--danger-hover); }
        .status { padding: 10px 14px; border-radius: 6px; margin-top: 12px; display: none; font-size: 13px; }
        .status.success { display: block; background: #eef6ec; color: var(--success); border: 1px solid #d4e6d1; }
        .status.error { display: block; background: #fef2f0; color: var(--danger); border: 1px solid #ffe0db; }
        .status.loading { display: block; background: #f0f4ff; color: var(--primary); border: 1px solid #d0dfff; }
        .settings-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
        .mobile-header { display: none; padding: 12px 16px; background: var(--card); border-bottom: 1px solid var(--border); align-items: center; justify-content: space-between; }
        .menu-toggle { background: none; border: none; font-size: 20px; cursor: pointer; color: var(--text-main); }
        .drawer-back { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 99; }
        .drawer-back.show { display: block; }
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.4);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal.show { display: flex; }
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 100%;
            max-width: 480px;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header { padding: 18px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
        .modal-header h3 { font-size: 16px; font-weight: 600; }
        .close-btn { background: none; border: none; font-size: 18px; cursor: pointer; color: var(--text-muted); padding: 4px; }
        .modal-body { padding: 20px; }
        .modal-footer { padding: 16px 20px; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 12px; }
        @media (max-width: 1024px) { .settings-row { grid-template-columns: 1fr 1fr; } }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); transition: transform 0.2s; z-index: 100; box-shadow: 2px 0 12px rgba(0,0,0,0.1); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .mobile-header { display: flex; }
            .top-bar { display: none; }
            .container { padding: 16px; }
            .settings-row { grid-template-columns: 1fr; }
            .section-body { padding: 16px; }
            .btn { padding: 10px 12px; min-height: 44px; justify-content: center; }
            .code-editor { min-height: 200px; }
        }
        @media (max-width: 480px) { .container { padding: 12px; } .section-body { padding: 12px; } }
    </style>
</head>
<body>
    <!-- 移动端顶部栏 -->
    <div class="mobile-header">
        <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
        <span style="font-weight:500;">月下独酌管机</span>
        <div></div>
    </div>

    <div class="desktop-layout">
        <!-- 侧边栏 -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h1>月下独酌管机</h1>
                <p>机器人管理后台</p>
            </div>
            <nav class="sidebar-nav">
                <a href="main.php" class="nav-item"><i class="fas fa-tachometer-alt"></i> 总览</a>
                <a href="#" class="nav-item" id="navAddBot"><i class="fas fa-plus-circle"></i> 添加机器人</a>
                <a href="set.php" class="nav-item"><i class="fas fa-user-cog"></i> 账号设置</a>
                <a href="simulate.php" class="nav-item"><i class="fas fa-vial"></i> 指令测试</a>
                <a href="cmdtest.php" class="nav-item"><i class="fas fa-paper-plane"></i> 主动消息</a>
                <a href="custom_api.php" class="nav-item"><i class="fas fa-code-branch"></i> API插件生成器</a>
                <a href="aidev.php" class="nav-item active"><i class="fas fa-robot"></i> AI 写插件</a>
                <a href="doc.php" class="nav-item"><i class="fas fa-file-alt"></i> 开发文档</a>
                <a href="update.php" class="nav-item"><i class="fas fa-cloud-upload-alt"></i> 在线更新</a>
            </nav>
            <div class="sidebar-footer">保留 1.0 原有逻辑 · 简洁商务版</div>
        </aside>

        <!-- 遮罩 -->
        <div class="drawer-back" id="drawerBack"></div>

        <!-- 主内容 -->
        <main class="main-content">
            <div class="top-bar">
                <div class="page-title">AI 写插件</div>
                <a href="main.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> 返回后台</a>
            </div>

            <div class="container">
                <!-- AI 配置 -->
                <div class="section-card">
                    <div class="section-header">
                        <div>
                            <div class="section-title">AI 配置</div>
                            <div class="section-sub">设置 OpenAI 兼容接口的地址、密钥和模型</div>
                        </div>
                    </div>
                    <div class="section-body">
                        <div class="settings-row">
                            <div class="form-group">
                                <label>Base URL</label>
                                <input type="text" class="form-control" id="base_url" value="<?= htmlspecialchars($ai['base_url'] ?? 'https://api.openai.com/v1') ?>" placeholder="https://api.openai.com/v1">
                            </div>
                            <div class="form-group">
                                <label>API Key</label>
                                <input type="password" class="form-control" id="api_key" value="<?= htmlspecialchars($displayKey) ?>" placeholder="sk-..." data-has-key="<?= $hasApiKey ? '1' : '0' ?>">
                            </div>
                            <div class="form-group">
                                <label>Model</label>
                                <input type="text" class="form-control" id="model" value="<?= htmlspecialchars($ai['model'] ?? 'gpt-4o-mini') ?>" placeholder="gpt-4o-mini">
                            </div>
                        </div>
                        <button class="btn btn-primary" id="saveConfigBtn"><i class="fas fa-save"></i> 保存配置</button>
                        <div id="configStatus" class="status"></div>
                    </div>
                </div>

                <!-- 描述需求 -->
                <div class="section-card">
                    <div class="section-header">
                        <div>
                            <div class="section-title">描述需求</div>
                            <div class="section-sub">用自然语言描述您要开发的插件功能，AI 将生成符合框架规范的 PHP 代码</div>
                        </div>
                    </div>
                    <div class="section-body">
                        <div class="form-group">
                            <label>需求描述</label>
                            <textarea class="form-control" id="prompt" rows="4" placeholder="例如：写一个插件，当用户发送“天气 北京”时，调用 curl 请求免费天气 API，并回复天气信息。"></textarea>
                        </div>
                        <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
                            <button class="btn btn-primary" id="generateBtn"><i class="fas fa-wand-magic-sparkles"></i> 生成代码</button>
                            <button class="btn btn-secondary" id="clearBtn">清空</button>
                            <span style="font-size:12px; color:var(--text-muted);">（含完整文档，可能需要 1-2 分钟）</span>
                        </div>
                        <div id="genStatus" class="status"></div>
                    </div>
                </div>

                <!-- 代码预览与保存 -->
                <div class="section-card">
                    <div class="section-header">
                        <div>
                            <div class="section-title">插件代码</div>
                            <div class="section-sub">预览并编辑生成的代码，填写插件名后保存</div>
                        </div>
                    </div>
                    <div class="section-body">
                        <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin-bottom:12px;">
                            <div style="flex:1; min-width:150px;">
                                <label style="font-size:13px; font-weight:500; color:var(--text-sub);">插件名（不含.php）</label>
                                <input type="text" class="form-control" id="pluginName" placeholder="例如: weather">
                            </div>
                            <button class="btn btn-success" id="saveBtn"><i class="fas fa-save"></i> 保存并启用</button>
                        </div>
                        <textarea class="form-control code-editor" id="codeEditor" rows="12" placeholder="生成的代码将显示在这里..."></textarea>
                        <div id="saveStatus" class="status"></div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- 添加机器人模态框 -->
    <div class="modal" id="addModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>添加机器人</h3>
                <button class="close-btn" data-close="addModal">&times;</button>
            </div>
            <form id="addForm">
                <div class="modal-body">
                    <div class="form-group">
                        <label>AppID</label>
                        <input type="text" class="form-control" id="addAppid" required placeholder="请输入机器人 AppID">
                    </div>
                    <div class="form-group">
                        <label>Secret</label>
                        <input type="text" class="form-control" id="addSecret" required placeholder="请输入机器人 Secret">
                    </div>
                    <div class="form-group">
                        <label>环境</label>
                        <select class="form-select" id="addEnvironment">
                            <option value="正式">正式环境</option>
                            <option value="沙箱">沙箱环境</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-close="addModal">取消</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </form>
        </div>
    </div>

    <div id="notification" class="notification"></div>

    <script>
        (function() {
            const $ = id => document.getElementById(id);
            const baseUrl = $('base_url'), apiKey = $('api_key'), model = $('model');
            const prompt = $('prompt'), codeEditor = $('codeEditor'), pluginName = $('pluginName');
            const genStatus = $('genStatus'), saveStatus = $('saveStatus'), configStatus = $('configStatus');

            // ========== Base64 工具函数 ==========
            function utf8ToBase64(str) {
                try {
                    return btoa(unescape(encodeURIComponent(str)));
                } catch(e) {
                    return str;
                }
            }

            // ========== 页面加载时从服务器重新获取配置 ==========
            async function loadConfigFromServer() {
                try {
                    const res = await fetch('api/aidev.php?action=get_config');
                    const json = await res.json();
                    if (json.success && json.config) {
                        baseUrl.value = json.config.base_url || 'https://api.openai.com/v1';
                        model.value = json.config.model || 'gpt-4o-mini';
                        const hasKey = json.config.api_key_set === true;
                        apiKey.dataset.hasKey = hasKey ? '1' : '0';
                        apiKey.value = hasKey ? '••••••••' : '';
                        apiKey.placeholder = hasKey ? '已设置，修改请输入新密钥' : 'sk-...';
                        return true;
                    }
                    return false;
                } catch (e) {
                    console.warn('加载配置失败:', e);
                    return false;
                }
            }

            function showMsg(text, isSuccess) {
                const el = document.getElementById('notification');
                el.textContent = text;
                el.className = 'notification ' + (isSuccess ? 'success' : 'error') + ' show';
                setTimeout(() => el.classList.remove('show'), 2500);
            }

            function showStatus(el, msg, type) {
                el.textContent = msg;
                el.className = 'status ' + type;
            }
            function hideStatus(el) { el.className = 'status'; }

            // ========== 模态框 ==========
            function closeModal(id) {
                const modal = document.getElementById(id);
                if (modal) modal.classList.remove('show');
            }
            function openModal(id) {
                const modal = document.getElementById(id);
                if (modal) modal.classList.add('show');
            }

            document.querySelectorAll('.modal').forEach(modal => {
                modal.addEventListener('click', function(e) {
                    if (e.target === this) this.classList.remove('show');
                });
            });
            document.querySelectorAll('[data-close]').forEach(btn => {
                btn.addEventListener('click', function() {
                    closeModal(this.dataset.close);
                });
            });

            // ========== 移动端菜单 ==========
            const sidebar = $('sidebar');
            const drawerBack = $('drawerBack');
            const menuToggle = $('menuToggle');

            function openSidebar() {
                sidebar.classList.add('open');
                drawerBack.classList.add('show');
            }
            function closeSidebar() {
                sidebar.classList.remove('open');
                drawerBack.classList.remove('show');
            }
            menuToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                if (sidebar.classList.contains('open')) closeSidebar();
                else openSidebar();
            });
            drawerBack.addEventListener('click', closeSidebar);
            document.addEventListener('click', (e) => {
                if (window.innerWidth <= 768) {
                    if (!sidebar.contains(e.target) && e.target !== menuToggle && !menuToggle.contains(e.target)) {
                        closeSidebar();
                    }
                }
            });

            // ========== 添加机器人 ==========
            document.getElementById('navAddBot').addEventListener('click', function(e) {
                e.preventDefault();
                openModal('addModal');
            });

            document.getElementById('addForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const addAppid = document.getElementById('addAppid').value.trim();
                const addSecret = document.getElementById('addSecret').value.trim();
                const addEnv = document.getElementById('addEnvironment').value;
                if (!addAppid || !addSecret) { 
                    showMsg('请填写完整信息', false); 
                    return; 
                }
                try {
                    const res = await fetch(`api/bot.php?type=add&appid=${encodeURIComponent(addAppid)}&secret=${encodeURIComponent(addSecret)}&environment=${encodeURIComponent(addEnv)}`);
                    const data = await res.json();
                    if (data.code === 200) { 
                        showMsg('添加成功', true); 
                        closeModal('addModal'); 
                        document.getElementById('addForm').reset(); 
                    } else {
                        showMsg(data.msg || '添加失败', false);
                    }
                } catch (err) { 
                    showMsg('网络错误: ' + err.message, false); 
                }
            });

            // ========== 保存配置（使用 Base64 编码密钥） ==========
            $('saveConfigBtn').addEventListener('click', async () => {
                // 获取当前输入值
                let keyValue = apiKey.value.trim();
                const hasKey = apiKey.dataset.hasKey === '1';
                
                // 如果输入框显示的是占位符，说明用户没有修改密钥
                if (keyValue === '••••••••') {
                    keyValue = '';
                }
                
                const data = {
                    base_url: baseUrl.value.trim(),
                    model: model.value.trim()
                };
                
                // 只有用户输入了新的密钥才发送（Base64编码）
                if (keyValue !== '') {
                    data.api_key = utf8ToBase64(keyValue);
                }
                
                showStatus(configStatus, '保存中...', 'loading');
                try {
                    const res = await fetch('api/aidev.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'save_config', ...data })
                    });
                    const json = await res.json();
                    if (json.success) {
                        showStatus(configStatus, '配置已保存，正在刷新...', 'success');
                        // 从服务器重新加载配置，不刷新页面
                        setTimeout(async function() {
                            await loadConfigFromServer();
                            showStatus(configStatus, '配置已加载', 'success');
                        }, 500);
                    } else {
                        showStatus(configStatus, json.error || '保存失败', 'error');
                    }
                } catch (e) {
                    showStatus(configStatus, '网络错误', 'error');
                }
            });

            // ========== 生成代码（使用 Base64 编码密钥） ==========
            $('generateBtn').addEventListener('click', async () => {
                const text = prompt.value.trim();
                if (!text) { showStatus(genStatus, '请描述需求', 'error'); return; }
                
                // 获取当前配置
                let cfg = {
                    base_url: baseUrl.value.trim(),
                    model: model.value.trim()
                };
                
                // 检查是否有密钥
                const hasKey = apiKey.dataset.hasKey === '1';
                const keyValue = apiKey.value.trim();
                
                // 如果输入框显示的是占位符，说明有密钥但不发送（后端从配置文件读取）
                // 如果用户输入了新密钥，Base64编码后发送
                if (keyValue === '••••••••') {
                    // 有密钥，但不发送给前端（后端从配置文件读取）
                    cfg.api_key = '';
                } else if (keyValue !== '') {
                    // 用户输入了新密钥，Base64编码
                    cfg.api_key = utf8ToBase64(keyValue);
                } else {
                    // 没有密钥
                    cfg.api_key = '';
                }
                
                // 如果没有密钥，提示用户配置
                if (!hasKey && !keyValue) {
                    showStatus(genStatus, '请先配置 API Key', 'error');
                    return;
                }
                
                showStatus(genStatus, 'AI 思考中（可能需要1-2分钟）...', 'loading');
                try {
                    const res = await fetch('api/aidev.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ action: 'generate', prompt: text, ...cfg })
                    });
                    const json = await res.json();
                    if (json.success) {
                        codeEditor.value = json.code;
                        // 尝试提取插件名
                        const nameMatch = json.code.match(/\/\/\s*插件[：:]\s*(.+?)\s*$/m) || json.code.match(/plugin\s*['"](.+?)['"]/);
                        if (nameMatch) {
                            pluginName.value = nameMatch[1].trim().replace(/\.php$/, '');
                        } else {
                            pluginName.value = 'auto_plugin_' + Date.now();
                        }
                        showStatus(genStatus, '生成成功，请预览并保存', 'success');
                    } else {
                        showStatus(genStatus, json.error || '生成失败', 'error');
                    }
                } catch (e) {
                    showStatus(genStatus, '网络错误', 'error');
                }
            });

            // ========== 保存插件 ==========
            $('saveBtn').addEventListener('click', async () => {
                const name = pluginName.value.trim();
                const code = codeEditor.value;
                if (!name) { showStatus(saveStatus, '请填写插件名', 'error'); return; }
                if (!code) { showStatus(saveStatus, '代码为空', 'error'); return; }
                showStatus(saveStatus, '保存中...', 'loading');
                try {
                    const formData = new FormData();
                    formData.append('action', 'save');
                    formData.append('name', name);
                    // Base64 编码代码，避免触发防火墙
                    formData.append('code', utf8ToBase64(code));
                    formData.append('encoded', '1');
                    
                    const res = await fetch('api/aidev.php', {
                        method: 'POST',
                        body: formData
                    });
                    const json = await res.json();
                    if (json.success) {
                        let msg = json.message || '保存成功';
                        if (json.warning) msg += '（' + json.warning + '）';
                        showStatus(saveStatus, msg, 'success');
                        // 清空输入，方便下次生成
                        if (!json.warning) {
                            setTimeout(function() {
                                prompt.value = '';
                                codeEditor.value = '';
                                pluginName.value = '';
                            }, 1500);
                        }
                    } else {
                        showStatus(saveStatus, json.error || '保存失败', 'error');
                    }
                } catch (e) {
                    showStatus(saveStatus, '网络错误：' + e.message, 'error');
                }
            });

            // ========== 清空 ==========
            $('clearBtn').addEventListener('click', () => {
                prompt.value = '';
                codeEditor.value = '';
                pluginName.value = '';
                hideStatus(genStatus);
                hideStatus(saveStatus);
            });

            // ========== 自动调整代码编辑器高度 ==========
            codeEditor.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = Math.min(this.scrollHeight, 600) + 'px';
            });

            // ========== 初始化：从服务器加载配置 ==========
            loadConfigFromServer();
        })();
    </script>
</body>
</html>