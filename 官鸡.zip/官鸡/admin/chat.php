<?php
if (!isset($_COOKIE['admin_token'])) {
    header("Location: index.php");
    exit();
}
$appid = $_GET['appid'] ?? '';
if (!$appid) die('缺少appid参数');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="referrer" content="no-referrer">
    <title>聊天记录 · 月下独酌管机</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
        :focus { outline:none; }
        :root {
            --bg: #f8fafc; --card: #ffffff; --border: #e9edf2;
            --text-main: #1a2c3e; --text-sub: #5e6f8d; --text-muted: #8b9ab0;
            --primary: #2c6b9e; --primary-hover: #235b87;
            --success: #2c6e2c; --danger: #c23d2e; --danger-hover: #a83426;
            --event-bg: #f0f4ff; --event-border: #d0dfff;
            --sidebar-width: 240px; --header-height: 52px; --chat-left-width: 280px;
            --safe-bottom: env(safe-area-inset-bottom, 0px);
        }
        body {
            background: var(--bg); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: var(--text-main); line-height:1.5; -webkit-text-size-adjust:100%;
            overflow:hidden; width:100%; height:100vh; height:-webkit-fill-available;
            position:fixed; top:0; left:0; right:0; bottom:0;
        }
        .desktop-layout { display:flex; height:100vh; height:-webkit-fill-available; overflow:hidden; }
        .main-content {
            flex:1; margin-left:var(--sidebar-width); height:100vh; height:-webkit-fill-available;
            min-width:0; overflow:hidden; display:flex; flex-direction:column;
        }
        .sidebar {
            width:var(--sidebar-width); background:var(--card); border-right:1px solid var(--border);
            position:fixed; top:0; bottom:0; left:0; display:flex; flex-direction:column;
            z-index:100; transition:transform 0.25s ease;
        }
        .sidebar-header { padding:20px 24px; border-bottom:1px solid var(--border); }
        .sidebar-header h1 { font-size:18px; font-weight:600; }
        .sidebar-header p { font-size:12px; color:var(--text-muted); margin-top:4px; }
        .sidebar-nav { flex:1; padding:16px 0; overflow-y:auto; }
        .nav-item {
            display:flex; align-items:center; gap:12px; padding:10px 24px;
            color:var(--text-sub); text-decoration:none; font-size:14px; font-weight:500;
            transition:all 0.15s; cursor:pointer;
        }
        .nav-item:hover { background:#f1f5f9; color:var(--primary); }
        .nav-item.active { background:#f1f5f9; color:var(--primary); border-left:3px solid var(--primary); padding-left:21px; }
        .nav-item i { width:20px; font-size:15px; }
        .sidebar-footer { padding:16px 24px; border-top:1px solid var(--border); font-size:11px; color:var(--text-muted); }
        .top-bar {
            background:var(--card); border-bottom:1px solid var(--border);
            padding:0 24px; height:var(--header-height); display:flex; align-items:center; justify-content:space-between;
            position:sticky; top:0; z-index:10; flex-shrink:0;
        }
        .page-title { font-size:15px; font-weight:500; }
        .back-btn {
            padding:6px 14px; border-radius:8px; background:#f1f5f9; color:var(--text-sub);
            text-decoration:none; font-size:12px; display:inline-flex; align-items:center; gap:6px;
        }
        .chat-wrapper { flex:1; display:flex; overflow:hidden; padding:12px; min-height:0; gap:0; }
        .chat-left {
            width:var(--chat-left-width); border:1px solid var(--border); border-right:0;
            padding:12px; background:#fafbfd; display:flex; flex-direction:column; gap:8px;
            overflow:hidden; border-radius:16px 0 0 16px; flex-shrink:0;
        }
        .chat-left .logo { font-size:18px; font-weight:700; color:var(--primary); margin-bottom:4px; white-space:nowrap; }
        .log-date-selector {
            display: flex; align-items: center; gap: 8px; margin: 8px 0;
        }
        .log-date-selector select {
            flex: 1; padding: 6px 8px; font-size: 12px; border: 1px solid var(--border); border-radius: 8px; background: white;
        }
        .chat-type { display:flex; border:1px solid var(--border); border-radius:10px; overflow:hidden; background:var(--card); flex-shrink:0; }
        .chat-type button {
            flex:1; border:0; background:transparent; padding:8px 0; font-weight:600;
            color:var(--text-sub); cursor:pointer; font-size:13px; transition:all 0.15s;
        }
        .chat-type .on { background:var(--primary); color:white; }
        .conversation-menu { flex:1; overflow-y:auto; display:flex; flex-direction:column; gap:4px; -webkit-overflow-scrolling:touch; }
        .conversation-menu button {
            border:1px solid var(--border); background:var(--card); cursor:pointer; text-align:left;
            padding:10px 12px; border-radius:10px; color:var(--text-main); transition:all 0.15s; font-size:13px; width:100%;
        }
        .conversation-menu button:hover { background:#f1f5f9; }
        .conversation-menu button.on { background:var(--primary); color:white; border-color:var(--primary); }
        .conversation-menu .item-row { display:flex; align-items:center; gap:8px; }
        .conversation-menu .item-av { width:28px; height:28px; border-radius:50%; overflow:hidden; background:#e9f0ff; flex:0 0 28px; display:grid; place-items:center; font-size:11px; color:var(--primary); }
        .conversation-menu .item-av img { width:100%; height:100%; object-fit:cover; display:block; }
        .conversation-menu .item-name { min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; font-size:13px; }
        .conversation-menu .meta { font-size:10px; color:var(--text-muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:2px; }
        .chat-right {
            flex:1; display:flex; flex-direction:column; min-width:0; min-height:0;
            overflow:hidden; border-radius:0 16px 16px 0; background:var(--card); border:1px solid var(--border);
            position:relative;
        }
        .chat-head {
            padding:12px 16px; border-bottom:1px solid var(--border); font-size:14px; font-weight:600;
            color:var(--text-main); background:#f9fafb; display:flex; align-items:center; gap:8px;
            flex-shrink:0; border-radius:0 16px 0 0;
        }
        .messages {
            flex:1; overflow-y:auto; min-height:0; padding:12px;
            display:flex; flex-direction:column; gap:10px;
            background:linear-gradient(180deg, #fcfdff 0%, #f6f8fc 100%);
            -webkit-overflow-scrolling:touch; position:relative;
        }
        .quick-panel {
            display:flex; gap:6px; padding:8px 12px; border-bottom:1px solid var(--border);
            flex-wrap:wrap; overflow-x:auto; -webkit-overflow-scrolling:touch; flex-shrink:0;
        }
        .q-item {
            background:#f1f5f9; border:1px solid var(--border); border-radius:8px;
            padding:5px 10px; font-size:12px; cursor:pointer; display:flex; align-items:center;
            gap:4px; color:var(--text-sub); transition:all 0.15s; white-space:nowrap; flex-shrink:0;
        }
        .q-item:hover, .q-item.active { background:var(--primary); color:white; border-color:var(--primary); }
        .q-item i { font-size:12px; }
        .chat-input-area {
            padding:10px 12px; padding-bottom:calc(10px + var(--safe-bottom));
            border-top:1px solid var(--border); display:flex; gap:8px; align-items:flex-end;
            flex-shrink:0; background:var(--card); z-index:4;
        }
        .chat-input-area textarea {
            flex:1; border:1px solid var(--border); border-radius:10px; padding:8px 12px;
            font-size:14px; resize:none; max-height:100px; min-height:40px; overflow-y:auto;
            background:#fafcfd; -webkit-overflow-scrolling:touch;
        }
        .chat-input-area button {
            width:40px; height:40px; border-radius:10px; border:none; cursor:pointer;
            font-weight:600; color:white; background:var(--primary); display:flex;
            align-items:center; justify-content:center; flex-shrink:0; font-size:16px;
        }
        .msg { max-width:85%; display:flex; gap:8px; align-items:flex-start; font-size:13px; position:relative; }
        .msg.in { align-self:flex-start; color:var(--text-main); }
        .msg.out { align-self:flex-end; color:white; flex-direction:row-reverse; }
        .msg .avatar-wrapper {
            position: relative;
            display: inline-block;
            flex-shrink: 0;
        }
        .msg .avatar {
            width:32px; height:32px; border-radius:50%; display:grid; place-items:center;
            font-size:12px; font-weight:700; overflow:hidden; background:#eef2ff; color:var(--primary);
            cursor:pointer;
        }
        .avatar img { width:100%; height:100%; object-fit:cover; display:block; }
        .msg .recall-icon {
            position: absolute;
            top: -6px;
            right: -8px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 1px 2px rgba(0,0,0,0.2);
            transition: transform 0.1s;
            z-index: 2;
        }
        .msg .recall-icon:hover { transform: scale(1.1); }
        .msg .recall-icon i { font-size: 10px; }
        .msg.recalled .bubble { opacity:0.6; background:#e9edf2; color:var(--text-muted); text-decoration:line-through; }
        .msg.recalled .bubble .text { text-decoration:line-through; }
        .msg.recalled .avatar { opacity:0.6; }
        .msg.recalled .recall-icon { display: none; }
        .msg .bubble {
            padding:8px 12px; border-radius:16px; max-width:100%; background:var(--card);
            border:1px solid var(--border); color:var(--text-main); box-shadow:0 1px 4px rgba(0,0,0,0.04);
            word-break:break-word; overflow-wrap:break-word; cursor:pointer; touch-action:pan-y;
            transition:background 0.1s;
        }
        .msg.out .bubble { background:var(--primary); color:white; border-color:var(--primary); }
        /* ========== 事件消息样式 ========== */
        .msg.event-msg .bubble {
            background: var(--event-bg);
            border-color: var(--event-border);
            color: var(--text-main);
            font-weight: 500;
            cursor: default;
        }
        .msg.event-msg .avatar {
            background: #e8edf5;
            color: var(--text-muted);
        }
        .msg.event-msg .bubble .text {
            color: var(--text-main);
            white-space: pre-wrap;
        }
        .msg.event-msg .meta {
            color: var(--text-muted);
        }
        .msg.event-msg .recall-icon {
            display: none !important;
        }
        .msg.event-msg .avatar img {
            border: 2px solid var(--event-border);
        }
        /* ========== 事件消息样式结束 ========== */
        .bubble .text { white-space:pre-wrap; word-break:break-word; overflow-wrap:anywhere; line-height:1.5; }
        .bubble .text a { color:inherit; text-decoration:underline; }
        .msg.out .bubble .text a { color:white; }
        .bubble .media { margin-top:8px; display:flex; flex-direction:column; gap:8px; }
        .bubble .media img { max-width:100%; border-radius:10px; display:block; cursor:pointer; max-height:300px; object-fit:contain; background:#f0f0f0; }
        .bubble .media video { max-width:100%; border-radius:10px; display:block; max-height:300px; background:#000; }
        .bubble .media audio { max-width:100%; display:block; }
        .bubble .media .file-link { display:flex; align-items:center; gap:8px; padding:8px; background:rgba(0,0,0,0.05); border-radius:8px; text-decoration:none; color:var(--primary); }
        .msg.out .bubble .media .file-link { background:rgba(255,255,255,0.2); color:white; }
        .msg.group .meta { font-size:11px; color:var(--text-muted); margin-bottom:3px; height:16px; }
        .msg.group .bubble { margin-top:0; }
        .context-menu {
            position:fixed; background:var(--card); border-radius:12px;
            box-shadow:0 4px 20px rgba(0,0,0,0.15); border:1px solid var(--border);
            z-index:1000; overflow:hidden; min-width:120px;
            animation:menuFadeIn 0.15s ease;
        }
        @keyframes menuFadeIn {
            from { opacity:0; transform:scale(0.95); }
            to { opacity:1; transform:scale(1); }
        }
        .context-menu-item {
            padding:12px 16px; display:flex; align-items:center; gap:12px;
            cursor:pointer; font-size:14px; transition:background 0.1s;
            color:var(--text-main);
        }
        .context-menu-item:hover { background:#f1f5f9; }
        .context-menu-item.danger { color:var(--danger); }
        .context-menu-item.danger:hover { background:#fef2f0; }
        .context-menu-item i { width:20px; font-size:14px; }
        .context-menu-divider { height:1px; background:var(--border); margin:4px 0; }
        .scroll-bottom-btn {
            position:absolute; bottom:16px; right:16px; width:38px; height:38px; border-radius:50%;
            background:var(--primary); color:white; border:none; cursor:pointer; display:flex;
            align-items:center; justify-content:center; font-size:16px; z-index:5;
            opacity:0; transform:translateY(20px); pointer-events:none; transition:opacity 0.25s, transform 0.25s;
        }
        .scroll-bottom-btn.visible { opacity:0.9; transform:translateY(0); pointer-events:auto; }
        .btn {
            display: inline-flex; align-items: center; justify-content: center;
            padding: 8px 16px; font-size: 13px; font-weight: 500;
            border-radius: 8px; border: none; cursor: pointer;
            transition: all 0.15s; white-space: nowrap; gap: 6px;
            text-decoration: none;
        }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-secondary { background: #f1f5f9; color: var(--text-sub); border: 1px solid var(--border); }
        .btn-secondary:hover { background: #e9edf2; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-danger:hover { background: var(--danger-hover); }
        .btn-sm { padding: 4px 8px; font-size: 12px; }
        .modal {
            display:none; position:fixed; inset:0; background:rgba(0,0,0,0.4);
            z-index:1000; align-items:center; justify-content:center; padding:20px;
        }
        .modal-content { background:white; border-radius:12px; width:100%; max-width:480px; max-height:90vh; overflow-y:auto; overflow-x:hidden; }
        .modal-header { padding:16px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; }
        .modal-header h3 { font-size:16px; font-weight:600; }
        .close-btn { background:none; border:none; font-size:18px; cursor:pointer; color:var(--text-muted); padding:4px; }
        .modal-body { padding:20px; }
        .modal-footer { padding:16px 20px; border-top:1px solid var(--border); display:flex; justify-content:flex-end; gap:12px; }
        .form-group { margin-bottom:14px; }
        .form-group label { display:block; font-size:13px; font-weight:600; margin-bottom:6px; color:var(--text-sub); }
        .form-control, .form-select { width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:10px; font-size:14px; background:white; }
        .notification {
            position:fixed; bottom:20px; right:20px; padding:10px 16px; border-radius:8px;
            font-size:13px; background:var(--text-main); color:white; z-index:1100;
            transform:translateX(120%); transition:transform 0.2s; max-width:calc(100vw - 40px);
        }
        .notification.show { transform:translateX(0); }
        .notification.success { background:var(--success); }
        .notification.error { background:var(--danger); }
        .mobile-header { display:none; padding:10px 14px; background:white; border-bottom:1px solid var(--border); align-items:center; justify-content:space-between; height:48px; }
        .menu-toggle { background:none; border:none; font-size:20px; cursor:pointer; color:var(--text-main); padding:4px; }
        .mobile-back { background:none; border:none; font-size:18px; cursor:pointer; color:var(--primary); padding:4px; display:none; }
        @media (max-width:1024px) {
            :root { --sidebar-width:220px; --chat-left-width:250px; }
            .top-bar { padding:0 16px; }
            .chat-wrapper { padding:8px; }
            .chat-left { padding:10px; }
        }
        @media (max-width:768px) {
            :root { --sidebar-width:260px; --chat-left-width:100%; }
            .sidebar { transform:translateX(-100%); z-index:200; box-shadow:2px 0 12px rgba(0,0,0,0.1); }
            .sidebar.open { transform:translateX(0); }
            .main-content { margin-left:0; }
            .mobile-header { display:flex; position:sticky; top:0; z-index:15; background:white; }
            .top-bar { display:none; }
            .chat-wrapper { flex-direction:column; padding:6px; flex:1; min-height:0; }
            .chat-left { width:100%; border:1px solid var(--border); border-radius:14px; transition:max-height 0.3s ease; flex-shrink:0; max-height:200px; }
            .chat-left.collapsed { max-height:48px; min-height:48px; overflow:hidden; }
            .chat-right { border-radius:14px; margin-top:6px; flex:1; min-height:0; display:flex; flex-direction:column; position:relative; }
            .chat-head { border-radius:14px 14px 0 0; flex-shrink:0; font-size:13px; padding:10px 14px; }
            .quick-panel { gap:4px; padding:6px 8px; overflow-x:auto; flex-wrap:nowrap; flex-shrink:0; }
            .q-item { padding:5px 8px; font-size:11px; }
            .messages { flex:1; min-height:0; padding:10px; font-size:14px; gap:8px; }
            .chat-input-area { padding:8px 10px; padding-bottom:calc(8px + var(--safe-bottom)); border-top:1px solid var(--border); background:var(--card); display:flex; gap:8px; align-items:flex-end; flex-shrink:0; }
            .chat-input-area textarea { font-size:16px; min-height:40px; }
            .chat-input-area button { width:44px; height:44px; }
            .msg { max-width:90%; gap:6px; }
            .msg .avatar { width:28px; height:28px; font-size:11px; }
            .msg .bubble { padding:7px 10px; border-radius:14px; font-size:13px; }
            .msg .recall-icon { width:16px; height:16px; top: -5px; right: -6px; }
            .msg .recall-icon i { font-size:8px; }
        }
        .image-preview-modal {
            position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.9);
            z-index:2000; display:none; align-items:center; justify-content:center;
            cursor:pointer;
        }
        .image-preview-modal img { max-width:95%; max-height:95%; object-fit:contain; }
        .image-preview-modal .close-preview {
            position:absolute; top:20px; right:20px; color:white; font-size:30px;
            background:none; border:none; cursor:pointer;
        }
    </style>
</head>
<body>
    <div class="mobile-header">
        <button class="menu-toggle" id="menuToggle"><i class="fas fa-bars"></i></button>
        <span style="font-weight:600;font-size:15px;">聊天记录</span>
        <button class="mobile-back" id="mobileBackBtn"><i class="fas fa-arrow-left"></i></button>
    </div>

    <div class="desktop-layout" id="desktopLayout">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h1>月下独酌管机</h1>
                <p>机器人管理后台</p>
            </div>
            <nav class="sidebar-nav">
                <a href="main.php" class="nav-item"><i class="fas fa-tachometer-alt"></i> 总览</a>
                <a href="#" class="nav-item" id="navAddBot"><i class="fas fa-plus-circle"></i> 添加机器人</a>
                <a href="set.php" class="nav-item"><i class="fas fa-user-cog"></i> 账号设置</a>
                <a href="simulate.php" class="nav-item"><i class="fas fa-vial"></i> 指令测试</a>
                <a href="cmdtest.php" class="nav-item"><i class="fas fa-paper-plane"></i> 主动消息</a>
                <a href="custom_api.php" class="nav-item"><i class="fas fa-code-branch"></i> API插件生成器</a>
                <a href="aidev.php" class="nav-item"><i class="fas fa-robot"></i> AI 写插件</a>
                <a href="doc.php" class="nav-item"><i class="fas fa-file-alt"></i> 开发文档</a>
                <a href="update.php" class="nav-item"><i class="fas fa-cloud-upload-alt"></i> 在线更新</a>
            </nav>
            <div class="sidebar-footer">保留 1.0 原有逻辑 · 简洁商务版</div>
        </aside>

        <main class="main-content" id="mainContent">
            <div class="top-bar">
                <div class="page-title">聊天记录</div>
                <a href="main.php" class="back-btn"><i class="fas fa-arrow-left"></i> 返回后台</a>
            </div>

            <div class="chat-wrapper">
                <div class="chat-left" id="chatLeft">
                    <div class="logo">✦ 会话列表</div>
                    <div class="log-date-selector">
                        <i class="fas fa-calendar-alt" style="color: var(--text-muted); font-size: 12px;"></i>
                        <select id="logDateSelect"><option value="">加载中...</option></select>
                        <button id="refreshLogBtn" class="btn btn-secondary btn-sm"><i class="fas fa-sync-alt"></i></button>
                    </div>
                    <div class="chat-type">
                        <button class="on" data-chat="private">私聊</button>
                        <button data-chat="group">群聊</button>
                    </div>
                    <div class="conversation-menu" id="menu"></div>
                </div>

                <div class="chat-right" id="chatRight">
                    <div class="chat-head" id="chatHead"><span>请选择会话</span></div>
                    <div class="quick-panel" id="quickPanel">
                        <div class="q-item active" data-method="text"><i class="fas fa-font"></i> 文字</div>
                        <div class="q-item" data-method="image"><i class="fas fa-image"></i> 图片</div>
                        <div class="q-item" data-method="voice"><i class="fas fa-microphone"></i> 语音</div>
                        <div class="q-item" data-method="video"><i class="fas fa-video"></i> 视频</div>
                        <div class="q-item" data-method="file"><i class="fas fa-file"></i> 文件</div>
                        <div class="q-item" data-method="quote"><i class="fas fa-quote-right"></i> 引用</div>
                        <div class="q-item" data-method="card"><i class="fas fa-id-card"></i> 卡片</div>
                        <div class="q-item" data-method="native_md"><i class="fas fa-markdown"></i> MD</div>
                    </div>
                    <div class="messages" id="messages">
                        <button class="scroll-bottom-btn" id="scrollBottomBtn" title="滚动到底部"><i class="fas fa-chevron-down"></i></button>
                    </div>
                    <div class="chat-input-area" id="chatInputArea">
                        <textarea id="chatInput" rows="1" placeholder="[文字] 输入消息..."></textarea>
                        <button id="sendBtn"><i class="fas fa-paper-plane"></i></button>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <div class="image-preview-modal" id="imagePreviewModal" onclick="closeImagePreview()">
        <button class="close-preview" onclick="closeImagePreview()">&times;</button>
        <img id="previewImage" src="" alt="预览">
    </div>

    <div class="modal" id="addModal">
        <div class="modal-content">
            <div class="modal-header"><h3>添加机器人</h3><button class="close-btn" data-close="addModal">&times;</button></div>
            <form id="addForm">
                <div class="modal-body">
                    <div class="form-group"><label>AppID</label><input type="text" class="form-control" id="addAppid" required placeholder="请输入机器人 AppID"></div>
                    <div class="form-group"><label>Secret</label><input type="text" class="form-control" id="addSecret" required placeholder="请输入机器人 Secret"></div>
                    <div class="form-group"><label>环境</label><select class="form-select" id="addEnvironment"><option value="正式">正式环境</option><option value="沙箱">沙箱环境</option></select></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-close="addModal">取消</button><button type="submit" class="btn btn-primary">添加</button></div>
            </form>
        </div>
    </div>

    <div id="notification" class="notification"></div>

    <script>
        // DOM 元素
        const $sidebar = document.getElementById('sidebar');
        const $menuToggle = document.getElementById('menuToggle');
        const $mobileBackBtn = document.getElementById('mobileBackBtn');
        const $chatLeft = document.getElementById('chatLeft');
        const $menu = document.getElementById('menu');
        const $messages = document.getElementById('messages');
        const $head = document.getElementById('chatHead');
        const $input = document.getElementById('chatInput');
        const $quickPanel = document.getElementById('quickPanel');
        const $sendBtn = document.getElementById('sendBtn');
        const $scrollBottomBtn = document.getElementById('scrollBottomBtn');
        const $mainContent = document.getElementById('mainContent');
        const $imagePreviewModal = document.getElementById('imagePreviewModal');
        const $previewImage = document.getElementById('previewImage');

        const appid = <?php echo json_encode($appid, JSON_UNESCAPED_UNICODE); ?>;
        let currentLogName = '';
        let currentMode = 'private';
        let listData = { private: [], group: [] };
        let activeChatId = '';
        let activeChatName = '';
        let sendMethod = 'text';
        let privateNickMap = {};
        let userNameMap = {};
        let lastMessageFingerprint = '';
        let liveTimer = null;
        let isUserScrolledUp = false;
        const userScrollThreshold = 60;
        let activeContextMenu = null;
        let recallingMessages = new Set();

        // 存储当前引用的消息ID（使用 REFIDX）
        let pendingQuoteId = null;

        const RECALLED_KEY = 'recalled_messages_' + appid;
        let recalledIds = new Set();

        function loadRecalledIds() {
            try {
                const stored = localStorage.getItem(RECALLED_KEY);
                if (stored) recalledIds = new Set(JSON.parse(stored));
            } catch(e) {}
        }
        function saveRecalledId(msgId) {
            if (!msgId) return;
            recalledIds.add(msgId);
            localStorage.setItem(RECALLED_KEY, JSON.stringify([...recalledIds]));
        }

        function showMsg(text, success) {
            const el = document.getElementById('notification');
            el.textContent = text;
            el.className = 'notification ' + (success ? 'success' : 'error') + ' show';
            setTimeout(() => el.classList.remove('show'), 2500);
        }

        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
        document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => closeModal(btn.dataset.close)));
        window.addEventListener('click', e => { if (e.target.classList.contains('modal')) e.target.style.display = 'none'; });

        function closeContextMenu() { if (activeContextMenu) { activeContextMenu.remove(); activeContextMenu = null; } }
        document.addEventListener('click', (e) => { if (!e.target.closest('.context-menu')) closeContextMenu(); });

        function updateMobileHeight() {
            if (window.innerWidth <= 768 && window.visualViewport) {
                const viewportHeight = window.visualViewport.height;
                if (viewportHeight) {
                    const headerHeight = document.querySelector('.mobile-header')?.offsetHeight || 48;
                    $mainContent.style.height = (viewportHeight - headerHeight) + 'px';
                }
            } else { $mainContent.style.height = ''; }
        }
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', updateMobileHeight);
            window.visualViewport.addEventListener('scroll', updateMobileHeight);
        }
        window.addEventListener('resize', updateMobileHeight);
        updateMobileHeight();

        $input.addEventListener('focus', () => {
            if (window.innerWidth <= 768) {
                setTimeout(() => { $messages.scrollTop = $messages.scrollHeight; updateMobileHeight(); }, 100);
            }
        });

        document.getElementById('navAddBot').addEventListener('click', e => { e.preventDefault(); document.getElementById('addModal').style.display = 'flex'; });
        document.getElementById('addForm').addEventListener('submit', async e => {
            e.preventDefault();
            const addAppid = document.getElementById('addAppid').value.trim();
            const addSecret = document.getElementById('addSecret').value.trim();
            const addEnv = document.getElementById('addEnvironment').value;
            if (!addAppid || !addSecret) { showMsg('请填写完整信息', false); return; }
            try {
                const res = await fetch(`api/bot.php?type=add&appid=${encodeURIComponent(addAppid)}&secret=${encodeURIComponent(addSecret)}&environment=${encodeURIComponent(addEnv)}`);
                const data = await res.json();
                if (data.code === 200) { showMsg('添加成功', true); closeModal('addModal'); document.getElementById('addForm').reset(); }
                else showMsg(data.msg || '添加失败', false);
            } catch (err) { showMsg('网络错误', false); }
        });

        function openSidebar() { $sidebar.classList.add('open'); }
        function closeSidebar() { $sidebar.classList.remove('open'); }
        $menuToggle.addEventListener('click', e => { e.stopPropagation(); $sidebar.classList.toggle('open'); });
        document.addEventListener('click', e => { if (window.innerWidth <= 768 && !$sidebar.contains(e.target) && e.target !== $menuToggle) closeSidebar(); });
        $mobileBackBtn.addEventListener('click', () => { if (window.innerWidth <= 768) { $chatLeft.classList.remove('collapsed'); $mobileBackBtn.style.display = 'none'; } });

        document.querySelectorAll('.chat-type button').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.chat-type button').forEach(b => b.classList.remove('on'));
                btn.classList.add('on');
                currentMode = btn.dataset.chat;
                activeChatId = '';
                activeChatName = '';
                lastMessageFingerprint = '';
                pendingQuoteId = null;
                if (liveTimer) clearInterval(liveTimer);
                $messages.innerHTML = '';
                const newBtn = document.createElement('button');
                newBtn.className = 'scroll-bottom-btn'; newBtn.id = 'scrollBottomBtn';
                newBtn.title = '滚动到底部'; newBtn.innerHTML = '<i class="fas fa-chevron-down"></i>';
                newBtn.addEventListener('click', scrollToBottom);
                $messages.appendChild(newBtn);
                $head.innerHTML = '<span>' + (currentMode === 'group' ? '群聊' : '私聊') + '</span>';
                renderMenu(); updateScrollButtonVisibility();
            });
        });

        function scrollToBottom() { $messages.scrollTo({ top: $messages.scrollHeight, behavior: 'smooth' }); isUserScrolledUp = false; updateScrollButtonVisibility(); }
        function updateScrollButtonVisibility() {
            const btn = $messages.querySelector('#scrollBottomBtn');
            if (!btn) return;
            const scrollBottom = $messages.scrollHeight - $messages.scrollTop - $messages.clientHeight;
            if (scrollBottom > userScrollThreshold) { btn.classList.add('visible'); isUserScrolledUp = true; }
            else { btn.classList.remove('visible'); isUserScrolledUp = false; }
        }
        $messages.addEventListener('scroll', updateScrollButtonVisibility);

        const methodPlaceholders = {
            text: '[文字] 输入消息...', image: '[图片] 输入图片URL...', voice: '[语音] 输入语音URL...',
            video: '[视频] 输入视频URL...', file: '[文件] 输入文件URL...', quote: '[引用] 输入回复内容',
            card: '[卡片] 输入内容（多行用 --- 分隔）', native_md: '[原生MD] 输入Markdown...'
        };
        $quickPanel.querySelectorAll('.q-item').forEach(item => {
            item.addEventListener('click', () => {
                $quickPanel.querySelectorAll('.q-item').forEach(el => el.classList.remove('active'));
                item.classList.add('active');
                sendMethod = item.dataset.method;
                $input.placeholder = methodPlaceholders[sendMethod] || '[文字] 输入消息...';
                $input.focus();
            });
        });

        function showContextMenu(x, y, options) {
            closeContextMenu();
            const menu = document.createElement('div');
            menu.className = 'context-menu';
            menu.style.left = x + 'px';
            menu.style.top = y + 'px';
            options.forEach(opt => {
                if (opt.divider) {
                    const divider = document.createElement('div');
                    divider.className = 'context-menu-divider';
                    menu.appendChild(divider);
                } else {
                    const item = document.createElement('div');
                    item.className = 'context-menu-item' + (opt.danger ? ' danger' : '');
                    item.innerHTML = `<i class="fas ${opt.icon}"></i><span>${opt.label}</span>`;
                    item.onclick = (e) => { e.stopPropagation(); closeContextMenu(); opt.action(); };
                    menu.appendChild(item);
                }
            });
            document.body.appendChild(menu);
            activeContextMenu = menu;
            const rect = menu.getBoundingClientRect();
            if (rect.right > window.innerWidth) menu.style.left = (window.innerWidth - rect.width - 10) + 'px';
            if (rect.bottom > window.innerHeight) menu.style.top = (window.innerHeight - rect.height - 10) + 'px';
            if (parseInt(menu.style.left) < 10) menu.style.left = '10px';
            if (parseInt(menu.style.top) < 10) menu.style.top = '10px';
        }

        async function recallMessage(messageId, messageElement) {
            if (!messageId) {
                showMsg('无法撤回：消息ID缺失', false);
                return;
            }
            if (recallingMessages.has(messageId)) return;
            recallingMessages.add(messageId);
            try {
                const form = new URLSearchParams({ type: 'recall', appid: appid, chat_type: currentMode, chat_id: activeChatId, message_id: messageId, name: currentLogName });
                const res = await fetch('api/chat.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form.toString() });
                const j = await res.json();
                if (j.code === 200) {
                    showMsg('撤回成功', true);
                    saveRecalledId(messageId);
                    if (messageElement) {
                        messageElement.classList.add('recalled');
                        const textDiv = messageElement.querySelector('.bubble .text');
                        if (textDiv && !messageElement.querySelector('.recall-badge')) {
                            textDiv.innerHTML = '<span class="recall-badge" style="opacity:0.7;"><i class="fas fa-undo-alt"></i> 已撤回</span>';
                        }
                        const recallIcon = messageElement.querySelector('.recall-icon');
                        if (recallIcon) recallIcon.style.display = 'none';
                    }
                } else { showMsg(j.msg || '撤回失败', false); }
            } catch (e) { showMsg('撤回失败: ' + e.message, false); }
            finally { recallingMessages.delete(messageId); }
        }

        function applyQuoteOnly(msgIdx) {
            $quickPanel.querySelectorAll('.q-item').forEach(el => el.classList.remove('active'));
            const qb = $quickPanel.querySelector('[data-method="quote"]');
            if (qb) qb.classList.add('active');
            sendMethod = 'quote';
            $input.placeholder = '[引用] 输入回复内容';
            pendingQuoteId = msgIdx;
            $input.value = '';
            $input.focus(); 
            adjustTextareaHeight();
            showMsg('已选择引用消息，输入回复内容后发送', true);
        }

        function setupMessageActions(msgElement, msgData) {
            if (!msgElement || !msgData) return;
            const bubble = msgElement.querySelector('.bubble');
            if (!bubble) return;

            // 事件消息不设置任何操作
            if (msgData.type === 'event') {
                bubble.style.cursor = 'default';
                return;
            }

            if (msgData.messageId) msgElement.dataset.msgId = msgData.messageId;
            if (msgData.msgIdx) msgElement.dataset.msgIdx = msgData.msgIdx;

            const isOwnMessage = (msgData.side === 'out') || (msgData.type === 'bot') || (msgData.name === '机器人');
            const canQuote = msgData.can_quote === true;

            let canRecall = false;
            if (isOwnMessage && msgData.messageId && msgData.time) {
                const msgTime = new Date(msgData.time.replace(' ', 'T')).getTime();
                const now = new Date().getTime();
                canRecall = (now - msgTime) <= 2 * 60 * 1000;
            }

            const isRecalled = msgElement.classList.contains('recalled');

            let startX = 0, startY = 0, isLongPress = false, longPressTimer = null;
            const clearLongPress = () => { if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; } isLongPress = false; };

            bubble.addEventListener('contextmenu', (e) => {
                e.preventDefault(); e.stopPropagation(); clearLongPress();
                const menuOptions = [];
                if (canQuote && msgData.msgIdx) {
                    menuOptions.push({ icon: 'fa-quote-right', label: '引用', action: () => { 
                        applyQuoteOnly(msgData.msgIdx); 
                    }});
                }
                if (!isRecalled && canRecall) {
                    if (menuOptions.length > 0) menuOptions.push({ divider: true });
                    menuOptions.push({ icon: 'fa-trash-alt', label: '撤回', danger: true, action: () => { recallMessage(msgData.messageId, msgElement); } });
                }
                if (menuOptions.length) showContextMenu(e.clientX, e.clientY, menuOptions);
            });

            bubble.addEventListener('touchstart', (e) => {
                const touch = e.touches[0];
                startX = touch.clientX; startY = touch.clientY;
                isLongPress = false;
                longPressTimer = setTimeout(() => {
                    isLongPress = true;
                    const menuOptions = [];
                    if (canQuote && msgData.msgIdx) {
                        menuOptions.push({ icon: 'fa-quote-right', label: '引用', action: () => { 
                            applyQuoteOnly(msgData.msgIdx); 
                        }});
                    }
                    if (!isRecalled && canRecall) {
                        if (menuOptions.length > 0) menuOptions.push({ divider: true });
                        menuOptions.push({ icon: 'fa-trash-alt', label: '撤回', danger: true, action: () => { recallMessage(msgData.messageId, msgElement); } });
                    }
                    if (menuOptions.length) showContextMenu(touch.clientX, touch.clientY, menuOptions);
                    clearLongPress();
                }, 500);
                if (navigator.vibrate) navigator.vibrate(50);
            }, { passive: true });

            bubble.addEventListener('touchmove', (e) => {
                if (!longPressTimer) return;
                const touch = e.touches[0];
                const dx = Math.abs(touch.clientX - startX);
                const dy = Math.abs(touch.clientY - startY);
                if (dx > 50 && dx > dy * 1.5 && !isLongPress) {
                    e.preventDefault(); clearLongPress();
                    if (canQuote && msgData.msgIdx) {
                        applyQuoteOnly(msgData.msgIdx);
                    }
                } else if (dx > 10 || dy > 10) { clearLongPress(); }
            }, { passive: false });

            bubble.addEventListener('touchend', () => { clearLongPress(); startX = startY = 0; });
            bubble.addEventListener('touchcancel', () => { clearLongPress(); startX = startY = 0; });
        }

        $sendBtn.addEventListener('click', () => sendMessage());
        $input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey) { e.preventDefault(); sendMessage(); } });
        function adjustTextareaHeight() { if (!$input) return; $input.style.height = 'auto'; $input.style.height = Math.min($input.scrollHeight, 100) + 'px'; }
        $input.addEventListener('input', adjustTextareaHeight);
        adjustTextareaHeight();

        async function sendMessage() {
            let content = $input.value.trim();
            if (!activeChatId) { showMsg('请先选择会话', false); return; }

            let finalSendMethod = sendMethod;
            let finalContent = content;
            let quoteId = pendingQuoteId;

            if (sendMethod === 'quote') {
                if (!quoteId) {
                    showMsg('请先长按/右键选择要引用的消息', false);
                    return;
                }
                if (!finalContent) {
                    finalContent = '';
                }
            } else {
                if (!finalContent) {
                    showMsg('请输入消息内容', false);
                    return;
                }
            }

            const form = new URLSearchParams({ 
                type: 'send', 
                appid, 
                chat_type: currentMode, 
                chat_id: activeChatId, 
                send_method: finalSendMethod, 
                content: finalContent, 
                name: currentLogName 
            });
            if (quoteId) {
                form.append('quote_id', quoteId);
            }

            try {
                const res = await fetch('api/chat.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form.toString() });
                const j = await res.json();
                if (j.code === 200) {
                    pendingQuoteId = null;
                    appendMsg({ side: 'out', text: finalContent, userId: '', avatarUrl: '', messageType: sendMethod, rawContent: finalContent, messageId: '', type: 'bot' });
                    $messages.scrollTop = $messages.scrollHeight; isUserScrolledUp = false; updateScrollButtonVisibility();
                    $input.value = ''; adjustTextareaHeight();
                    $quickPanel.querySelectorAll('.q-item').forEach(el => el.classList.remove('active'));
                    const textBtn = $quickPanel.querySelector('[data-method="text"]');
                    if (textBtn) textBtn.classList.add('active');
                    sendMethod = 'text';
                    $input.placeholder = methodPlaceholders.text;
                    setTimeout(() => refreshCurrentMessages(true).catch(()=>{}), 500);
                } else showMsg(j.msg || '发送失败', false);
            } catch (e) { showMsg('网络错误', false); }
        }

        function shortText(t) { t = (t||'').replace(/\s+/g,' ').trim(); return t.length>28 ? t.slice(0,28)+'…' : t; }

        /**
         * 获取头像显示文本 - 支持事件类型显示特殊图标
         */
        function avatarText(name, id, type) {
            if (!name && !id) return '?';
            // 事件类型显示特殊图标
            if (type === 'event') {
                if (name === '群成员增加') return '👤';
                if (name === '群成员删除') return '🚫';
                if (name === '添加好友') return '➕';
                if (name === '删除好友') return '➖';
                return '📋';
            }
            // 普通用户：取名字第一个字符
            if (name && name.length > 0) {
                return name.charAt(0).toUpperCase();
            }
            return (id || '?').slice(0,1).toUpperCase();
        }

        /**
         * 获取头像URL
         * 私聊/群聊用户使用QQ头像
         * 群聊使用群头像
         */
        function getAvatarUrlByMode(mode, id) {
            if (!id) return '';
            // 私聊或事件使用QQ用户头像
            // 格式: https://q.qlogo.cn/qqapp/{appid}/{openid}/640
            return `https://q.qlogo.cn/qqapp/${appid}/${id}/640`;
        }

        function avatarImgHtml(mode, id, name, type) {
            const ch = avatarText(name, id, type);
            const url = getAvatarUrlByMode(mode, id);
            if (type === 'event') {
                // 事件类型使用特殊样式
                return `<span style="font-size:16px;">${ch}</span>`;
            }
            // 如果有头像URL，显示图片；否则显示文字
            if (url) {
                return `<img src="${url}" alt="${ch}" onerror="this.style.display='none';this.parentElement.textContent='${ch}';" style="width:100%;height:100%;object-fit:cover;">`;
            }
            return ch;
        }

        function escapeHtml(s) { 
            if (!s) return '';
            return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); 
        }

        function renderTextWithMentions(text) { return (text||'').replace(/\r\n/g,'\n').replace(/<@([^>]+)>/g, (_,uid) => `@${userNameMap[uid]||uid}`); }

        function renderMarkdownToHtml(text, msgType, msg) {
            let s = renderTextWithMentions(text || '');
            s = escapeHtml(s);
            s = s.replace(/\n/g,'<br>');
            if (msg.attachments && msg.attachments.length) {
                for (const att of msg.attachments) {
                    const url = att.url || '';
                    const contentType = att.content_type || '';
                    if (contentType.startsWith('image/') || url.match(/\.(jpg|jpeg|png|gif|webp|bmp)/i)) {
                        s += `<div class="media"><img src="${escapeHtml(url)}" alt="图片" loading="lazy" onclick="openImagePreview('${escapeHtml(url)}')" style="cursor:pointer;max-width:100%;border-radius:10px;"></div>`;
                    } else if (contentType.startsWith('video/') || url.match(/\.(mp4|webm|mov)/i)) {
                        s += `<div class="media"><video controls preload="metadata" style="max-width:100%;border-radius:10px;max-height:300px;"><source src="${escapeHtml(url)}"></video></div>`;
                    } else if (contentType == "voice") {
                        const wavUrl = att.voice_wav_url || url;
                        s += `<div class="media"><audio controls src="${escapeHtml(wavUrl)}" style="max-width:100%;"></audio></div>`;
                    } else if (contentType == "file" || att.filename) {
                        s += `<div class="media"><a href="${escapeHtml(url)}" target="_blank" class="file-link"><i class="fas fa-file"></i> ${escapeHtml(att.filename || '下载文件')}</a></div>`;
                    }
                }
            }
            return s;
        }

        function safeRenderMessageHtml(text, type, msg) {
            try { return renderMarkdownToHtml(text, type, msg); }
            catch(e) { return escapeHtml(renderTextWithMentions(text||'')).replace(/\n/g,'<br>'); }
        }

        function messageFingerprint(m) { return m ? [m.time||'', m.type||'', m.user_id||'', m.content||'', m.message_id||''].join('|') : ''; }

        function openImagePreview(url) { $previewImage.src = url; $imagePreviewModal.style.display = 'flex'; }
        function closeImagePreview() { $imagePreviewModal.style.display = 'none'; $previewImage.src = ''; }
        window.openImagePreview = openImagePreview;
        window.closeImagePreview = closeImagePreview;

        async function loadPrivateNicknames() {
            const ids = (listData.private||[]).map(i=>i.id).filter(Boolean);
            if(!ids.length) return;
            try {
                const res = await fetch('api/chat.php', { 
                    method:'POST', 
                    headers:{'Content-Type':'application/x-www-form-urlencoded'}, 
                    body: new URLSearchParams({
                        type:'get_nicknames', 
                        appid, 
                        name:currentLogName, 
                        user_ids:ids.join(',')
                    }) 
                });
                const j = await res.json();
                if(j.code===200 && j.nicknames) { 
                    privateNickMap = j.nicknames; 
                    Object.entries(privateNickMap).forEach(([uid,n]) => { 
                        if(n) userNameMap[uid]=n; 
                    });
                }
            } catch(e) {
                console.warn('加载昵称失败:', e);
            }
        }

        async function loadList() {
            if (!currentLogName) return;
            try {
                const res = await fetch(`api/chat.php?type=list&appid=${encodeURIComponent(appid)}&name=${encodeURIComponent(currentLogName)}`);
                const j = await res.json();
                if(j.code!==200) { $menu.innerHTML='<div style="color:var(--text-muted);">暂无数据</div>'; return; }
                listData.group = j.groups||[]; 
                listData.private = j.privates||[];
                await loadPrivateNicknames(); 
                renderMenu();
            } catch(e) { 
                console.warn('加载会话列表失败:', e);
                $menu.innerHTML='<div style="color:var(--danger);">加载失败</div>'; 
            }
        }

        function renderMenu() {
            const arr = currentMode==='group' ? listData.group : listData.private;
            if(!arr.length) { $menu.innerHTML='<div style="color:var(--text-muted);">暂无会话</div>'; return; }
            $menu.innerHTML = arr.map(it => {
                // 获取显示名称
                let title = it.id;
                if (currentMode === 'private') {
                    title = privateNickMap[it.id] || it.id || '用户';
                }
                const isActive = (activeChatId === it.id);
                const avatarUrl = getAvatarUrlByMode(currentMode, it.id);
                const avatarChar = title.charAt(0).toUpperCase() || '?';
                
                return `<button class="${isActive ? 'on' : ''}" data-id="${it.id}" data-name="${escapeHtml(title)}">
                    <div class="item-row">
                        <div class="item-av">${avatarUrl ? `<img src="${avatarUrl}" alt="${escapeHtml(title)}" onerror="this.style.display='none';this.parentElement.textContent='${avatarChar}';">` : escapeHtml(avatarChar)}</div>
                        <div class="item-name">${escapeHtml(title)}</div>
                    </div>
                    <div class="meta">${escapeHtml(shortText(it.last_message))} · ${it.last_message_time||''}</div>
                </button>`;
            }).join('');
            $menu.querySelectorAll('button').forEach(btn => {
                btn.addEventListener('click', () => {
                    const item = arr.find(i=>i.id===btn.dataset.id);
                    if(item) { openChat(item); if(window.innerWidth<=768) closeSidebar(); }
                });
            });
        }

        async function refreshCurrentMessages(silent=true) {
            if(!activeChatId || !currentLogName) return;
            try {
                const res = await fetch(`api/chat.php?type=messages&appid=${encodeURIComponent(appid)}&name=${encodeURIComponent(currentLogName)}&chat_type=${currentMode}&chat_id=${encodeURIComponent(activeChatId)}`);
                const j = await res.json();
                if(j.code!==200 || !Array.isArray(j.messages)) return;
                const last = j.messages.length ? j.messages[j.messages.length-1] : null;
                const fp = messageFingerprint(last);
                if(!silent || fp!==lastMessageFingerprint) {
                    $messages.innerHTML = '';
                    const btn = document.createElement('button');
                    btn.className='scroll-bottom-btn'; btn.id='scrollBottomBtn'; btn.title='滚动到底部';
                    btn.innerHTML='<i class="fas fa-chevron-down"></i>';
                    btn.addEventListener('click', scrollToBottom);
                    $messages.appendChild(btn);
                    for (const m of j.messages) {
                        if(m.user_id&&m.username) userNameMap[m.user_id]=m.username;
                        appendMsg(normalizeMessage(m));
                    }
                    if(!isUserScrolledUp) $messages.scrollTop = $messages.scrollHeight;
                    updateScrollButtonVisibility();
                    lastMessageFingerprint = fp;
                }
            } catch(e) {
                console.warn('刷新消息失败:', e);
            }
        }

        function startLiveRefresh() { 
            if(liveTimer) clearInterval(liveTimer); 
            liveTimer = setInterval(()=>refreshCurrentMessages(true).catch(()=>{}), 3000); 
        }

        async function openChat(item) {
            activeChatId = item.id;
            if (currentMode === 'private') {
                activeChatName = privateNickMap[item.id] || item.id || '用户';
            } else {
                activeChatName = item.id;
            }
            renderMenu();
            $head.innerHTML = `<span>${currentMode==='group'?'群聊':'私聊'} ${escapeHtml(activeChatName)}</span>`;
            if(window.innerWidth<=768) { $chatLeft.classList.add('collapsed'); $mobileBackBtn.style.display='block'; }
            isUserScrolledUp = false; updateScrollButtonVisibility();
            pendingQuoteId = null;
            await refreshCurrentMessages(false); 
            startLiveRefresh();
        }

        /**
         * 规范化消息数据 - 完整支持事件类型和头像
         */
        function normalizeMessage(m) {
            // 判断是否是事件类型
            const isEvent = m.type === 'event';
            const isBot = m.type === 'bot';

            let userId = m.user_id || '';
            let username = m.username || '系统事件';
            let side = 'in';
            let canQuote = m.can_quote === true && !isEvent;

            if (isBot) {
                side = 'out';
                username = '机器人';
            } else if (isEvent) {
                side = 'in';
                canQuote = false;
                // 根据内容设置事件类型名称
                if (m.content && m.content.includes('群成员增加')) {
                    username = '群成员增加';
                } else if (m.content && m.content.includes('群成员删除')) {
                    username = '群成员删除';
                } else if (m.content && m.content.includes('添加好友')) {
                    username = '添加好友';
                } else if (m.content && m.content.includes('删除好友')) {
                    username = '删除好友';
                } else if (m.content && m.content.includes('机器人被加入群聊')) {
                    username = '系统事件';
                } else if (m.content && m.content.includes('机器人退出群聊')) {
                    username = '系统事件';
                }
            }

            const baseMsg = {
                side: side,
                name: username,
                userId: userId,
                text: m.content || '',
                messageType: m.message_type || 'text',
                rawContent: m.content || '',
                messageId: m.message_id || '',
                msgIdx: m.msg_idx || '',
                time: m.time,
                can_quote: canQuote,
                attachments: m.attachments || null,
                card_data: m.card_data || null,
                type: m.type || (isBot ? 'bot' : (isEvent ? 'event' : 'user'))
            };

            if(baseMsg.userId && baseMsg.name) userNameMap[baseMsg.userId] = baseMsg.name;
            if(isBot) { baseMsg.side = 'out'; baseMsg.name = '机器人'; }

            // 生成头像 - 事件类型使用特殊处理
            baseMsg.avatar = avatarText(baseMsg.name, baseMsg.userId, isEvent ? 'event' : null);
            // 获取头像URL
            baseMsg.avatarUrl = getAvatarUrlByMode('private', baseMsg.userId);

            return baseMsg;
        }

        /**
         * 添加消息到聊天界面 - 完整支持事件类型和头像
         */
        function appendMsg(m) {
            const wrap = document.createElement('div');
            const isGroup = currentMode === 'group';
            const isEvent = m.type === 'event';

            // 事件消息使用特殊的样式类
            wrap.className = `msg ${m.side} ${isGroup ? 'group' : ''} ${isEvent ? 'event-msg' : ''}`;

            const isOwn = (m.side === 'out') || (m.type === 'bot') || (m.name === '机器人');
            let canRecall = false;
            if (isOwn && m.messageId && m.time && !isEvent) {
                try {
                    const msgTime = new Date(m.time.replace(' ', 'T')).getTime();
                    const now = new Date().getTime();
                    canRecall = (now - msgTime) <= 2 * 60 * 1000;
                } catch(e) {}
            }

            // 事件消息显示特殊背景
            const eventClass = isEvent ? 'event-bubble' : '';

            // 构建头像内容
            let avatarContent = '';
            if (isEvent) {
                // 如果有用户ID且有头像URL，显示用户头像
                if (m.userId && m.avatarUrl) {
                    avatarContent = `<img src="${m.avatarUrl}" alt="头像" onerror="this.style.display='none';this.parentElement.textContent='${m.avatar}';" style="width:100%;height:100%;object-fit:cover;">`;
                } else {
                    // 否则显示事件图标
                    if (m.name === '群成员增加') avatarContent = '👤';
                    else if (m.name === '群成员删除') avatarContent = '🚫';
                    else if (m.name === '添加好友') avatarContent = '➕';
                    else if (m.name === '删除好友') avatarContent = '➖';
                    else avatarContent = '📋';
                }
            } else {
                // 普通消息：显示头像图片或文字
                if (m.avatarUrl) {
                    avatarContent = `<img src="${m.avatarUrl}" alt="${m.avatar}" onerror="this.style.display='none';this.parentElement.textContent='${m.avatar}';" style="width:100%;height:100%;object-fit:cover;">`;
                } else {
                    avatarContent = m.avatar || '?';
                }
            }

            const avatarHtml = `
                <div class="avatar-wrapper">
                    <div class="avatar">${avatarContent}</div>
                    ${canRecall ? `<div class="recall-icon" data-msgid="${escapeHtml(m.messageId)}"><i class="fas fa-trash-alt"></i></div>` : ''}
                </div>
            `;

            if (isGroup && m.side === 'in') {
                wrap.innerHTML = `${avatarHtml}<div><div class="meta">${escapeHtml(m.name)}</div><div class="bubble ${eventClass}"><div class="text"></div></div></div>`;
            } else {
                wrap.innerHTML = `${avatarHtml}<div class="bubble ${eventClass}"><div class="text"></div></div>`;
            }

            // 处理已撤回消息
            if (m.messageId && recalledIds.has(m.messageId)) {
                wrap.classList.add('recalled');
                const textDiv = wrap.querySelector('.bubble .text');
                if (textDiv && !textDiv.querySelector('.recall-badge')) {
                    textDiv.innerHTML = '<span class="recall-badge" style="opacity:0.7;"><i class="fas fa-undo-alt"></i> 已撤回</span>';
                }
                const recallIcon = wrap.querySelector('.recall-icon');
                if (recallIcon) recallIcon.style.display = 'none';
            }

            const textDiv = wrap.querySelector('.text');
            if(textDiv) {
                if (isEvent) {
                    textDiv.textContent = m.text || m.rawContent || '';
                } else {
                    textDiv.innerHTML = safeRenderMessageHtml(m.text||'', m.messageType||'text', m);
                }
            }

            // 用户头像点击@功能（仅非事件消息且有userId）
            const av = wrap.querySelector('.avatar');
            if(av && m.side === 'in' && m.userId && !isEvent) {
                av.style.cursor = 'pointer';
                av.title = `@${m.userId}`;
                av.addEventListener('click', e => {
                    e.stopPropagation();
                    const mention = `<@${m.userId}> `;
                    if(!$input.value.includes(`<@${m.userId}>`)) {
                        $input.value = ($input.value ? $input.value + ' ' : '') + mention;
                    }
                    $input.focus(); 
                    adjustTextareaHeight();
                    try{$input.setSelectionRange($input.value.length,$input.value.length);}catch(_){}
                });
            }

            // 撤回按钮（仅非事件消息）
            const recallIcon = wrap.querySelector('.recall-icon');
            if (recallIcon && m.messageId && !isEvent) {
                recallIcon.addEventListener('click', (e) => {
                    e.stopPropagation();
                    recallMessage(m.messageId, wrap);
                });
            }

            // 设置消息操作（事件消息不设置）
            setupMessageActions(wrap, m);

            const scrollBtn = $messages.querySelector('#scrollBottomBtn');
            if(scrollBtn) $messages.insertBefore(wrap, scrollBtn);
            else $messages.appendChild(wrap);
        }

        /**
         * 获取今天的日期字符串（格式：YYYY-MM-DD）
         * 使用本地时间，避免时区问题
         */
        function getTodayDateString() {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            return year + '-' + month + '-' + day;
        }

        async function loadLogFiles() {
            const select = document.getElementById('logDateSelect');
            if (!select) return;
            select.innerHTML = '<option value="">加载中...</option>';
            try {
                const res = await fetch(`api/log.php?type=list&appid=${encodeURIComponent(appid)}`);
                const data = await res.json();
                if (data.code === 200 && data.list && data.list.length) {
                    const files = data.list.sort().reverse();
                    let html = '';
                    let defaultFile = '';
                    const today = getTodayDateString() + '.log';

                    files.forEach(file => {
                        html += `<option value="${escapeHtml(file)}">${escapeHtml(file)}</option>`;
                        if (file === today) defaultFile = today;
                    });
                    select.innerHTML = html;

                    if (defaultFile && files.includes(defaultFile)) {
                        select.value = defaultFile;
                    } else if (files.length) {
                        select.value = files[0];
                    }

                    if (select.value) {
                        currentLogName = select.value;
                    } else {
                        currentLogName = today;
                    }
                } else {
                    select.innerHTML = '<option value="">暂无日志文件</option>';
                    currentLogName = getTodayDateString() + '.log';
                }
            } catch (err) {
                console.error('加载日志文件列表失败:', err);
                select.innerHTML = '<option value="">加载失败</option>';
                currentLogName = getTodayDateString() + '.log';
            }
            await loadList();
            if (activeChatId) { 
                await refreshCurrentMessages(false); 
                startLiveRefresh(); 
            }
        }

        async function switchLogFile() {
            const select = document.getElementById('logDateSelect');
            if (!select || !select.value) return;
            const newLogName = select.value;
            if (newLogName === currentLogName) return;
            currentLogName = newLogName;
            activeChatId = '';
            activeChatName = '';
            lastMessageFingerprint = '';
            pendingQuoteId = null;
            if (liveTimer) clearInterval(liveTimer);
            $messages.innerHTML = '';
            const btn = document.createElement('button');
            btn.className = 'scroll-bottom-btn'; btn.id = 'scrollBottomBtn';
            btn.title = '滚动到底部'; btn.innerHTML = '<i class="fas fa-chevron-down"></i>';
            btn.addEventListener('click', scrollToBottom);
            $messages.appendChild(btn);
            $head.innerHTML = '<span>' + (currentMode === 'group' ? '群聊' : '私聊') + '</span>';
            await loadList();
            updateScrollButtonVisibility();
        }

        const logDateSelect = document.getElementById('logDateSelect');
        if (logDateSelect) logDateSelect.addEventListener('change', switchLogFile);
        const refreshLogBtn = document.getElementById('refreshLogBtn');
        if (refreshLogBtn) refreshLogBtn.addEventListener('click', () => loadLogFiles());

        loadRecalledIds();
        loadLogFiles();

        setInterval(() => { 
            if (currentLogName) loadList(); 
        }, 15000);

        updateScrollButtonVisibility();
    </script>
</body>
</html>