<?php
header('Content-Type: application/json; charset=utf-8');

// 开启错误日志
ini_set('log_errors', 1);
ini_set('error_log', dirname(__DIR__, 2) . '/error.log');

if (!isset($_COOKIE['admin_token'])) {
    http_response_code(401);
    die(json_encode(['code' => 401, 'msg' => '未登录']));
}

// 获取输入（支持 JSON 和 FormData 两种方式）
$input = [];
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
if (strpos($contentType, 'application/json') !== false) {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: [];
} else {
    // FormData 方式
    $input = $_POST;
}

$type = $input['type'] ?? $_GET['type'] ?? '';
$appid = $input['appid'] ?? $_GET['appid'] ?? '';
$name = $input['name'] ?? $_GET['name'] ?? '';

$mainFile = dirname(__DIR__, 2) . '/main.json';
$pluginDir = dirname(__DIR__, 2) . '/plugin/';

switch ($type) {
    case 'list':
        // 读取 appid 的插件启用状态
        $maincontent = file_get_contents($mainFile);
        $json = json_decode($maincontent, true);
        $plugins = $json[$appid]['plugin'] ?? [];
        echo json_encode($plugins);
        break;

    case 'open':
        $maincontent = file_get_contents($mainFile);
        $json = json_decode($maincontent, true);
        $json[$appid]['plugin'][$name] = true;
        if (file_put_contents($mainFile, json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) === false) {
            die(json_encode(['code' => 500, 'msg' => '写入配置失败，请检查权限']));
        }
        echo json_encode(['code' => 200, 'msg' => '已启用']);
        break;

    case 'close':
        $maincontent = file_get_contents($mainFile);
        $json = json_decode($maincontent, true);
        unset($json[$appid]['plugin'][$name]);
        if (file_put_contents($mainFile, json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) === false) {
            die(json_encode(['code' => 500, 'msg' => '写入配置失败，请检查权限']));
        }
        echo json_encode(['code' => 200, 'msg' => '已禁用']);
        break;

    case 'filelist':
        $files = glob($pluginDir . '*.php');
        $list = [];
        foreach ($files as $file) {
            $list[] = basename($file, '.php');
        }
        echo json_encode(['code' => 200, 'list' => $list]);
        break;

    case 'add':
        if (empty($name)) {
            die(json_encode(['code' => 400, 'msg' => '插件名不能为空']));
        }
        // 安全过滤
        $name = preg_replace('/[^a-zA-Z0-9_\x{4e00}-\x{9fa5}]/u', '', $name);
        if (empty($name)) {
            die(json_encode(['code' => 400, 'msg' => '插件名不合法']));
        }
        $path = $pluginDir . $name . '.php';
        if (is_file($path)) {
            die(json_encode(['code' => 400, 'msg' => '插件已存在']));
        }
        // 确保 plugin 目录存在
        if (!is_dir($pluginDir)) {
            mkdir($pluginDir, 0755, true);
        }
        $content = "<?php\n\n// 插件：" . $name . "\n// 生成时间：" . date('Y-m-d H:i:s') . "\n\n?>";
        if (file_put_contents($path, $content) === false) {
            die(json_encode(['code' => 500, 'msg' => '创建失败，请检查权限']));
        }
        echo json_encode(['code' => 200, 'msg' => '创建成功']);
        break;

    case 'delete':
        if (empty($name)) {
            die(json_encode(['code' => 400, 'msg' => '插件名不能为空']));
        }
        $path = $pluginDir . $name . '.php';
        if (!is_file($path)) {
            die(json_encode(['code' => 400, 'msg' => '插件不存在']));
        }
        if (unlink($path) === false) {
            die(json_encode(['code' => 500, 'msg' => '删除失败，请检查权限']));
        }
        echo json_encode(['code' => 200, 'msg' => '删除成功']);
        break;

    case 'read':
        if (empty($name)) {
            die(json_encode(['code' => 400, 'msg' => '插件名不能为空']));
        }
        $path = $pluginDir . $name . '.php';
        if (!is_file($path)) {
            die(json_encode(['code' => 400, 'msg' => '插件不存在']));
        }
        $content = file_get_contents($path);
        if ($content === false) {
            die(json_encode(['code' => 500, 'msg' => '读取失败']));
        }
        echo json_encode(['code' => 200, 'msg' => $content]);
        break;

    case 'write':
        if (empty($name)) {
            die(json_encode(['code' => 400, 'msg' => '插件名不能为空']));
        }
        // 支持 JSON 和 FormData 两种方式
        $content = $input['content'] ?? '';
        
        // 如果是 Base64 编码，先解码
        if (isset($input['encoded']) && $input['encoded'] == '1') {
            $content = base64_decode($content);
            if ($content === false) {
                die(json_encode(['code' => 500, 'msg' => '代码解码失败']));
            }
        }
        
        if (empty($content) && $content !== '0') {
            // 允许空内容（清空文件）
        }
        
        $path = $pluginDir . $name . '.php';
        // 确保 plugin 目录存在
        if (!is_dir($pluginDir)) {
            mkdir($pluginDir, 0755, true);
        }
        if (file_put_contents($path, $content) === false) {
            die(json_encode(['code' => 500, 'msg' => '写入失败，请检查权限']));
        }
        echo json_encode(['code' => 200, 'msg' => '保存成功']);
        break;

    default:
        echo json_encode(['code' => 400, 'msg' => '无效的操作类型']);
}