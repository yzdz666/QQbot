<?php
$file = dirname(__DIR__,2)."/main.json";
$main = file_get_contents($file);
$main = json_decode($main,true);
$type = $_REQUEST["type"] ?? "";

if (empty($type)) {
    $json = [
        "code" => 400,
        "msg" => "未传入数据"
    ];
    echo json_encode($json,480);
    exit;
}

switch ($type) {
    case "add":
        $appid = $_REQUEST["appid"] ?? "";
        $secret = $_REQUEST["secret"] ?? "";
        $environment = $_REQUEST["environment"] ?? "";
        $main[$appid] = [
            "secret" => $secret,
            "type" => $environment
        ];
        $json = json_encode($main,480);
        file_put_contents($file,$json);
        $json = [
            "code" => 200,
            "msg" => "添加成功"
        ];
        echo json_encode($json,480);
        break;
        
    case "del":
        $appid = $_REQUEST["appid"] ?? "";
        unset($main[$appid]);
        $json = json_encode($main,480);
        file_put_contents($file,$json);
        $json = [
            "code" => 200,
            "msg" => "删除成功"
        ];
        echo json_encode($json,480);
        break;
        
    case "switch_env":
        $appid = $_REQUEST["appid"] ?? "";
        $environment = $_REQUEST["environment"] ?? "";
        
        if (empty($appid) || empty($environment)) {
            $json = [
                "code" => 400,
                "msg" => "缺少必要参数"
            ];
            echo json_encode($json,480);
            exit;
        }
        
        if (!isset($main[$appid])) {
            $json = [
                "code" => 404,
                "msg" => "机器人不存在"
            ];
            echo json_encode($json,480);
            exit;
        }
        
        // 更新环境配置
        $main[$appid]["type"] = $environment;
        $jsonStr = json_encode($main,480);
        if (file_put_contents($file, $jsonStr) === false) {
            $json = [
                "code" => 500,
                "msg" => "保存配置失败"
            ];
            echo json_encode($json,480);
            exit;
        }
        
        $json = [
            "code" => 200,
            "msg" => "切换成功"
        ];
        echo json_encode($json,480);
        break;
        
    default:
        $json = [
            "code" => 400,
            "msg" => "无效的操作类型"
        ];
        echo json_encode($json,480);
}