<?php

// ==================== 增强版日志记录函数 ====================
function 记录发送($action, $target, $content, $type = "文字", $messageId = null) {
    $logEntry = [
        "direction" => "发送",
        "action" => $action,
        "source_type" => 消息来源,
        "target_id" => $target,
        "content_type" => $type,
        "content" => $content,
        "time" => date("Y-m-d H:i:s")
    ];
    if (!empty($messageId)) {
        $logEntry["id"] = $messageId;
    }
    wlog(json_encode($logEntry, JSON_UNESCAPED_UNICODE));
}

function BOT凭证(){
       $time=读("function/".appid,"time",0);
       if (time() < $time) {
         return 读("function/".appid,"Access",0);
       } else {
         $url="https://bots.qq.com/app/getAppAccessToken";
         $appid=appid;
         $secret=secret;
         $json=json_encode([
         "appId"=>"{$appid}",
         "clientSecret"=>$secret
         ]);
         $header=['Content-Type: application/json'];
         $fw=curl($url,"POST",$header,$json);
         写(1,1,$json);
         $fw=json_decode($fw,true);
         $Access=$fw["access_token"];
         $time=$fw["expires_in"];
         写("function/".appid,"time",time()+$time);
         写("function/".appid,"Access",$Access);
         return $Access;
      }
}

function BOTAPI($Address,$me,$json){
    $urls=[
    "正式"=>"https://api.sgroup.qq.com",
    "沙箱"=>"https://sandbox.api.sgroup.qq.com"
    ];
    $url = $urls[type].$Address;
    $header = ["Authorization: QQBot ".BOT凭证(), 'Content-Type: application/json'];
    $curl=curl($url,$me,$header,$json);
    return $curl;
}

function 文字($content) {
   switch (消息来源) {
     case "群聊":
        $json = json_encode([
        "content" => "{$content}",
        "msg_type" => 0,
        "msg_id" => 消息ID,
        "msg_seq" => rand(1,99999)
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文字", 来源, $content, "文字", $messageId);
         return $resp;
         break;
     case "私聊":
        $jsonData = [
        "content" => "{$content}",
        "msg_type" => 0,
        "msg_seq" => rand(1,99999)
         ];
         if (defined('事件ID')) $jsonData["event_id"] = 事件ID;
         else $jsonData["msg_id"] = 消息ID;
         $resp = BOTAPI("/v2/users/".来源."/messages","POST",json_encode($jsonData));
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文字", 来源, $content, "文字", $messageId);
         return $resp;
         break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
        $json = json_encode([
        "content" => "{$content}",
        "msg_type" => 0,
        "event_id" => 事件ID,
        "msg_seq" => rand(1,99999)
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文字", 来源, $content, "文字", $messageId);
         return $resp;
         break;
     case "文字子频道":
         $json = json_encode([
         "content" => $content,
         "msg_id" => 消息ID
         ]);
         $resp = BOTAPI("/channels/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文字", 来源, $content, "文字", $messageId);
         return $resp;
         break;
   }
}


function 富媒体($type,$image,$name = null) {
    $types = ["图片" => 1, "视频" => 2, "语音" => 3 , "文件" => 4];
    $t = $types[$type] ?? 1;
    if (preg_match('/^http(s)?:\/\//i', $image)) {
        $jsonData = [
            "file_type" => $t,
            "url" => $image,
            "file_name" => $name,
            "srv_send_msg" => false
        ];
    } else {
        $jsonData = [
            "file_type" => $t,
            "file_data" => base64_encode($image),
            "file_name" => $name,
            "srv_send_msg" => false
        ];
    }
    $json = json_encode($jsonData);
        switch (消息来源) {
           case "加群":
           case "退群":
           case "群成员增加":   // 新增
           case "群成员移除":   // 新增
           case "群聊":
           case "互动":
               return json_decode(BOTAPI("/v2/groups/".来源."/files", "POST",$json),true);
               break;
           case "私聊":
               return json_decode(BOTAPI("/v2/users/".来源."/files", "POST",$json),true);
               break;
        }
}


function 图片($image,$content=null) {
   $logContent = $content ?? "[图片]";
   switch (消息来源) {
     case "群聊":
        $file_info =富媒体("图片",$image);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
        "content" => $content !== null ? "\n{$content}" : "",
        "msg_type" => 7,
        "msg_id" => 消息ID,
        "msg_seq" => mt_rand(1, 9999),
        "media" => ["file_info" => $file]
        ]);
        $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送图片", 来源, $logContent, "图片", $messageId);
        return $resp;
        break;
     case "私聊":
        $file_info =富媒体("图片",$image);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
        "content" => "{$content}",
        "msg_type" => 7,
        "msg_id" => 消息ID,
        "msg_seq" => mt_rand(1, 9999),
        "media" => ["file_info" => $file]
        ]);
        $resp = BOTAPI("/v2/users/".来源."/messages","POST",$json);
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送图片", 来源, $logContent, "图片", $messageId);
        return $resp;
        break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
        $file_info =富媒体("图片",$image);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
        "content" => "{$content}",
        "msg_type" => 7,
        "event_id" => 事件ID,
        "msg_seq" => mt_rand(1, 9999),
        "media" => ["file_info" => $file]
        ]);
        $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送图片", 来源, $logContent, "图片", $messageId);
        return $resp;
        break;
     case "文字子频道":
         $json = json_encode([
             "content" => $content,
             "file_image" => $image,
             "msg_id" => 消息ID
         ]);
         $resp = BOTAPI("/channels/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送图片", 来源, $logContent, "图片", $messageId);
         return $resp;
         break;
   }
}


function silk($link){
    $link = str_replace("&","%26",$link);
    $url = "https://oiapi.net/API/Mp32Silk?url=".$link;
    $r = json_decode(curl($url,"GET",[],''), true);
    return $r["message"] ?? '';
}

// ==================== 本地语音功能 ====================
function 本地语音($yy) {
   switch (消息来源) {
     case "群聊":
        $file_info = 富媒体("语音",$yy);
        if (isset($file_info['message'])) {
         return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "msg_id" => 消息ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送本地语音", 来源, "[本地语音文件]", "语音", $messageId);
         return $resp;
         break;
     case "私聊":
       $file_info = 富媒体("语音",$yy);
         if (isset($file_info['message'])) {
         return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "msg_id" => 消息ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/users/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送本地语音", 来源, "[本地语音文件]", "语音", $messageId);
         return $resp;
         break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
      $file_info = 富媒体("语音",$yy);
          if (isset($file_info['message'])) {
         return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "event_id" => 事件ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送本地语音", 来源, "[本地语音文件]", "语音", $messageId);
         return $resp;
         break;
   }
}

function 语音($yy) {
   switch (消息来源) {
     case "群聊":
        $silk = silk($yy);
        $file_info = 富媒体("语音",$silk);
        if (isset($file_info['message'])) {
         return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "msg_id" => 消息ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送语音", 来源, "[语音文件]", "语音", $messageId);
         return $resp;
         break;
     case "私聊":
        $silk = silk($yy);
        $file_info = 富媒体("语音",$silk);
        if (isset($file_info['message'])) {
         return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "msg_id" => 消息ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/users/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送语音", 来源, "[语音文件]", "语音", $messageId);
         return $resp;
         break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
        $silk = silk($yy);
        $file_info = 富媒体("语音",$silk);
        if (isset($file_info['message'])) {
         return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "event_id" => 事件ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送语音", 来源, "[语音文件]", "语音", $messageId);
         return $resp;
         break;
   }
}

function 文件($yy, $nm = null) {
    // 自动提取文件名（如果未提供）
    if ($nm === null) {
        $nm = 'file';
        $path = parse_url($yy, PHP_URL_PATH);
        if ($path) {
            $basename = basename($path);
            if ($basename && strpos($basename, '.') !== false) {
                $nm = $basename;
            }
        }
        // 去除查询参数（如 ?token=xxx）
        $nm = preg_replace('/\?.*$/', '', $nm);
        if (empty($nm)) $nm = 'file';
    }
    
   switch (消息来源) {
     case "群聊":
        $file_info = 富媒体("文件",$yy,$nm);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "msg_id" => 消息ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文件", 来源, "[文件: {$nm}]", "文件", $messageId);
         return $resp;
         break;
     case "私聊":
        $file_info = 富媒体("文件",$yy,$nm);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "msg_id" => 消息ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/users/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文件", 来源, "[文件: {$nm}]", "文件", $messageId);
         return $resp;
         break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
        $file_info = 富媒体("文件",$yy,$nm);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
          "msg_type" => 7,
          "event_id" => 事件ID,
          "msg_seq" => mt_rand(1, 9999),
          "media" => ["file_info" => $file]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送文件", 来源, "[文件: {$nm}]", "文件", $messageId);
         return $resp;
         break;
   }
}


function 视频($video) {
   switch (消息来源) {
     case "群聊":
        $file_info =富媒体("视频",$video);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
        "msg_type" => 7,
        "msg_id" => 消息ID,
        "msg_seq" => mt_rand(1, 9999),
        "media" => ["file_info" => $file]
        ]);
        $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送视频", 来源, "[视频文件]", "视频", $messageId);
        return $resp;
        break;
     case "私聊":
        $file_info =富媒体("视频",$video);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
        "msg_type" => 7,
        "msg_id" => 消息ID,
        "msg_seq" => mt_rand(1, 9999),
        "media" => ["file_info" => $file]
        ]);
        $resp = BOTAPI("/v2/users/".来源."/messages","POST",$json);
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送视频", 来源, "[视频文件]", "视频", $messageId);
        return $resp;
        break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
        $file_info =富媒体("视频",$video);
        if (isset($file_info['message'])) {
          return 文字($file_info['message']);
        }
        $file = $file_info['file_info'];
        $json = json_encode([
        "msg_type" => 7,
        "event_id" => 事件ID,
        "msg_seq" => mt_rand(1, 9999),
        "media" => ["file_info" => $file]
        ]);
        $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送视频", 来源, "[视频文件]", "视频", $messageId);
        return $resp;
        break;
   }
}


function 按钮($key) {
   switch (消息来源) {
     case "群聊":
         $json = json_encode([
         "msg_type" => 2,
         "msg_id" => 消息ID,
         "msg_seq" => mt_rand(1, 9999),
         "keyboard" => [
           "id" => $key
           ]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送按钮", 来源, "[按钮ID: {$key}]", "按钮", $messageId);
         return $resp;
         break;
     case "私聊":
        $json = json_encode([
         "msg_type" => 2,
         "msg_id" => 消息ID,
         "msg_seq" => mt_rand(1, 9999),
         "keyboard" => [
           "id" => $key
           ]
         ]);
         $resp = BOTAPI("/v2/users/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送按钮", 来源, "[按钮ID: {$key}]", "按钮", $messageId);
         return $resp;
         break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
     case "互动":
        $json = json_encode([
         "msg_type" => 2,
         "event_id" => 事件ID,
         "msg_seq" => mt_rand(1, 9999),
         "keyboard" => [
           "id" => $key
           ]
         ]);
         $resp = BOTAPI("/v2/groups/".来源."/messages","POST",$json);
         $data = json_decode($resp, true);
         $messageId = $data['id'] ?? '';
         记录发送("发送按钮", 来源, "[按钮ID: {$key}]", "按钮", $messageId);
         return $resp;
         break;
   }
}

function 头像($id){
   return "https://q.qlogo.cn/qqapp/".appid."/{$id}/640";
}

function BOT信息(){
  return BOTAPI("/users/@me","GET",0);
}

function 文卡(...$items) {
    // 构建日志内容
    $itemTexts = [];
    foreach ($items as $item) {
        $itemTexts[] = $item['text'] ?? '[文本]';
    }
    
    $list_items = [];
    foreach ($items as $item) {
        if (isset($item['url'])) {
            $list_items[] = [
                "obj_kv" => [
                    ["key" => "desc", "value" => $item['text']],
                    ["key" => "link", "value" => $item['url']]
                ]
            ];
        } else {
            $list_items[] = [
                "obj_kv" => [
                    ["key" => "desc", "value" => $item['text']]
                ]
            ];
        }
    }
    $json = [
        "msg_type" => 3,
        "msg_seq" => mt_rand(1, 9999),
        "ark" => [
            "template_id" => 23,
            "kv" => [
                ["key" => "#DESC#", "value" => "忘了吧"],
                ["key" => "#PROMPT#", "value" => "忘了吧"],
                ["key" => "#LIST#", "obj" => $list_items]
            ]
        ]
    ];
    switch (消息来源) {
         case "群聊":
           if (defined('事件ID')) $json["event_id"] = 事件ID;
           else $json["msg_id"] = 消息ID;
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送文卡", 来源, implode(" | ", $itemTexts), "文卡", $messageId);
           return $resp;
         break;
         case "私聊":
           if (defined('事件ID')) $json["event_id"] = 事件ID;
           else $json["msg_id"] = 消息ID;
           $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送文卡", 来源, implode(" | ", $itemTexts), "文卡", $messageId);
           return $resp;
         break;
         case "加群":
         case "退群":
         case "群成员增加":   // 新增
         case "群成员移除":   // 新增
         case "互动":
           $json["event_id"] = 事件ID;
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送文卡", 来源, implode(" | ", $itemTexts), "文卡", $messageId);
           return $resp;
         break;
    }
}

function 大图($title,$xtitle,$iurl){
    $json = [
        "msg_type" => 3,
        "msg_seq" => mt_rand(1, 9999),
        "ark" => [
            "template_id" => 37,
            "kv" => [
                ["key" => "#METATITLE#", "value" => $title],
                ["key" => "#METASUBTITLE#", "value" => $xtitle],
                ["key" => "#PROMPT#", "value" => "忘了吧"],
                ["key" => "#METACOVER#", "value" => $iurl]
            ]
        ]
    ];
    switch (消息来源) {
         case "群聊":
           if (defined('事件ID')) $json["event_id"] = 事件ID;
           else $json["msg_id"] = 消息ID;
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送大图卡片", 来源, "标题: {$title}", "大图卡片", $messageId);
           return $resp;
         break;
         case "私聊":
           if (defined('事件ID')) $json["event_id"] = 事件ID;
           else $json["msg_id"] = 消息ID;
           $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送大图卡片", 来源, "标题: {$title}", "大图卡片", $messageId);
           return $resp;
         break;
         case "加群":
         case "退群":
         case "群成员增加":   // 新增
         case "群成员移除":   // 新增
         case "互动":
           $json["event_id"] = 事件ID;
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送大图卡片", 来源, "标题: {$title}", "大图卡片", $messageId);
           return $resp;
         break;
    }
}

function 跳转卡($title,$desc,$image,$tz){
    $json = [
        "msg_type" => 3,
        "msg_seq" => mt_rand(1, 9999),
        "ark" => [
            "template_id" => 24,
            "kv" => [
                ["key" => "#DESC#", "value" => "忘了吧"],
                ["key" => "#PROMPT#", "value" => "忘了吧"],
                ["key" => "#TITLE#", "value" => $title],
                ["key" => "#METADESC#", "value" => $desc],
                ["key" => "#IMG#", "value" => $image],
                ["key" => "#LINK#", "value" => $tz],
                ["key" => "#SUBTITLE#", "value" => "忘了吧"]
            ]
        ]
    ];
    switch (消息来源) {
         case "群聊":
           if (defined('事件ID')) $json["event_id"] = 事件ID;
           else $json["msg_id"] = 消息ID;
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送跳转卡片", 来源, "标题: {$title}, 链接: {$tz}", "跳转卡片", $messageId);
           return $resp;
         break;
         case "私聊":
           if (defined('事件ID')) $json["event_id"] = 事件ID;
           else $json["msg_id"] = 消息ID;
           $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送跳转卡片", 来源, "标题: {$title}, 链接: {$tz}", "跳转卡片", $messageId);
           return $resp;
         break;
         case "加群":
         case "退群":
         case "群成员增加":   // 新增
         case "群成员移除":   // 新增
         case "互动":
           $json["event_id"] = 事件ID;
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json));
           $data = json_decode($resp, true);
           $messageId = $data['id'] ?? '';
           记录发送("发送跳转卡片", 来源, "标题: {$title}, 链接: {$tz}", "跳转卡片", $messageId);
           return $resp;
         break;
    }
}

function 流式(...$msgs){
    $id = null;
    $index = 0;
    $total = count($msgs);
    $lastResp = null;
    foreach ($msgs as $msg) {
        $isLast = ($index === $total - 1);
        $json = [
            "content" => (string)$msg,
            "msg_id" => 消息ID,
            "msg_seq" => rand(1, 99999),
            "stream" => [
                "state" => $isLast ? 10 : 1,
                "id" => $id,
                "index" => $index,
                "reset" => false
            ]
        ];
        $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($json));
        $lastResp = $resp;
        $json = json_decode($resp, true);
        $id = $json["id"] ?? null;
        $index++;
    }
    $content_preview = implode(" ", array_slice($msgs, 0, 2));
    记录发送("流式回复", 来源, $content_preview . (count($msgs) > 2 ? " ..." : ""), "流式", $id);
    return $lastResp;
}

function 撤回($id){
   记录发送("撤回消息", 来源, "消息ID: {$id}", "撤回");
   $type = [
      "群聊"=>"groups",
      "私聊"=>"users",
      "加群"=>"groups",
      "退群"=>"groups",
      "群成员增加"=>"groups",   // 新增
      "群成员移除"=>"groups"    // 新增
   ];
   $type = $type[消息来源];
   return BOTAPI("/v2/{$type}/".来源."/messages/".$id,"DELETE","");
}

function 互动私聊(){
   return 消息来源 == "互动" && (
      (raw["d"]["scene"] ?? "") == "c2c" ||
      (string)(raw["d"]["chat_type"] ?? "") == "2" ||
      (!isset(raw["d"]["group_openid"]) && isset(raw["d"]["user_openid"]))
   );
}

function 互动目标用户(){
   return raw["d"]["user_openid"] ?? 来源;
}

// ==================== 引用消息函数 ====================
function 引用($msgId, $content = '') {
    $payload = [
        "content" => $content ?: "",
        "message_reference" => [
            "message_id" => $msgId,
            "ignore_get_message_error" => true
        ]
    ];
    
    // 根据消息来源设置不同的参数
    switch (消息来源) {
        case "群聊":
            $payload["msg_id"] = 消息ID;
            $payload["msg_seq"] = rand(1, 99999);
            $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($payload, JSON_UNESCAPED_UNICODE));
            break;
            
        case "私聊":
            $payload["msg_id"] = 消息ID;
            $payload["msg_seq"] = rand(1, 99999);
            $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($payload, JSON_UNESCAPED_UNICODE));
            break;
            
        case "加群":
        case "退群":
        case "群成员增加":   // 新增
        case "群成员移除":   // 新增
        case "互动":
            $payload["event_id"] = 事件ID;
            $payload["msg_seq"] = rand(1, 99999);
            $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($payload, JSON_UNESCAPED_UNICODE));
            break;
            
        case "文字子频道":
            $payload["msg_id"] = 消息ID;
            $resp = BOTAPI("/channels/".来源."/messages", "POST", json_encode($payload, JSON_UNESCAPED_UNICODE));
            break;
            
        default:
            // 不支持的来源，降级为文字发送
            return 文字($content ?: "");
    }
    
    // 解析响应，获取返回的消息ID
    $data = json_decode($resp, true);
    $returnedMsgId = $data['id'] ?? '';
    
    // 记录日志，带上返回的消息ID
    记录发送("发送引用消息", 来源, $content ?: "", "引用", $returnedMsgId);
    
    return $resp;
}

// ==================== MD函数（已升级，支持style参数） ====================
function MD($md, $keyboard = null, $style = null) {
   $json = [
       "msg_type" => 2,
       "msg_seq" => rand(1, 9999),
       "markdown" => [
           "content" => $md
       ]
   ];
   
   // 添加 style 参数支持
   if ($style !== null && is_array($style)) {
       $json["markdown"]["style"] = $style;
   }
   
   if ($keyboard !== null) {
       $json["keyboard"] = ["id" => $keyboard];
   }
   
   switch (消息来源) {
     case "群聊":
        if (defined('事件ID')) $json["event_id"] = 事件ID;
        else $json["msg_id"] = 消息ID;
        $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送MD", 来源, $md, "MD", $messageId);
        return $resp;
        break;
     case "私聊":
        if (defined('事件ID')) $json["event_id"] = 事件ID;
        else $json["msg_id"] = 消息ID;
        $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送MD", 来源, $md, "MD", $messageId);
        return $resp;
        break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
        $json["event_id"] = 事件ID;
        $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送MD", 来源, $md, "MD", $messageId);
        return $resp;
        break;
     case "互动":
        $json["event_id"] = 事件ID;
        if (互动私聊()) {
           $resp = BOTAPI("/v2/users/".互动目标用户()."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        } else {
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        }
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送MD", 来源, $md, "MD", $messageId);
        return $resp;
        break;
   }
}

function 原生按钮($md, $rows) {
   $json = [
       "msg_type" => 2,
       "msg_seq" => rand(1, 9999),
       "markdown" => [
           "content" => $md
       ],
       "keyboard" => [
           "content" => [
               "rows" => $rows
           ]
       ]
   ];

   switch (消息来源) {
     case "群聊":
        $json["msg_id"] = 消息ID;
        $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送原生自定义按钮", 来源, $md, "原生按钮", $messageId);
        return $resp;
        break;
     case "私聊":
        $json["msg_id"] = 消息ID;
        $resp = BOTAPI("/v2/users/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送原生自定义按钮", 来源, $md, "原生按钮", $messageId);
        return $resp;
        break;
     case "加群":
     case "退群":
     case "群成员增加":   // 新增
     case "群成员移除":   // 新增
        $json["event_id"] = 事件ID;
        $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送原生自定义按钮", 来源, $md, "原生按钮", $messageId);
        return $resp;
        break;
     case "互动":
        $json["event_id"] = 事件ID;
        if (互动私聊()) {
           $resp = BOTAPI("/v2/users/".互动目标用户()."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        } else {
           $resp = BOTAPI("/v2/groups/".来源."/messages", "POST", json_encode($json, JSON_UNESCAPED_UNICODE));
        }
        $data = json_decode($resp, true);
        $messageId = $data['id'] ?? '';
        记录发送("发送原生自定义按钮", 来源, $md, "原生按钮", $messageId);
        return $resp;
        break;
   }
}

// ==================== 发MD函数（已升级，支持style参数） ====================
function 发MD($template_id, $params, $keyboard_id = null, $style = null) {
    if (isset($params['key']) && isset($params['values'])) {
        $params = [$params];
    }
    
    $json_data = [
        "content" => "",
        "msg_type" => 2,
        "msg_seq" => mt_rand(1, 99999),
        "markdown" => [
            "custom_template_id" => $template_id,
            "params" => $params
        ]
    ];
    
    // 添加 style 参数支持
    if ($style !== null && is_array($style)) {
        $json_data["markdown"]["style"] = $style;
    }
    
    if (!empty($keyboard_id)) {
        $json_data["keyboard"] = ["id" => $keyboard_id];
    }
    
    // 根据来源设置 event_id 或 msg_id
    if (in_array(消息来源, ["加群", "退群", "群成员增加", "群成员移除", "互动"])) {  // 新增群成员增加/移除
        $json_data["event_id"] = 事件ID;
    } else {
        $json_data["msg_id"] = 消息ID;
    }
    
    switch (消息来源) {
        case "群聊":
        case "加群":
        case "退群":
        case "群成员增加":   // 新增
        case "群成员移除":   // 新增
        case "互动":
            $api_url = "/v2/groups/" . 来源 . "/messages";
            break;
        case "私聊":
            $api_url = "/v2/users/" . 来源 . "/messages";
            break;
        case "文字子频道":
            $api_url = "/channels/" . 来源 . "/messages";
            break;
        default:
            return "错误：消息来源不支持";
    }
    
    $resp = BOTAPI($api_url, "POST", json_encode($json_data, JSON_UNESCAPED_UNICODE));
    $data = json_decode($resp, true);
    $messageId = $data['id'] ?? '';
    
    // 构建日志内容
    $logParams = [];
    if (isset($params['key']) && isset($params['values'])) {
        $logParams[] = $params['key'] . ":" . implode(",", $params['values']);
    } elseif (is_array($params)) {
        foreach ($params as $p) {
            if (isset($p['key'])) {
                $logParams[] = $p['key'];
            }
        }
    }
    记录发送("发送自定义MD", 来源, "模板: {$template_id} " . implode(" ", $logParams), "自定义MD", $messageId);
    return $resp;
}